// Copyright Xyzto Works

#include "Widgets/ActionSlot.h"

#include "Components/Border.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"
#include "Data/AbilityDefinition.h"
#include "Engine/Texture2D.h"
#include "Nevergone.h"

void UActionSlot::NativePreConstruct()
{
    Super::NativePreConstruct();

    // Apply default idle visuals in the editor viewport so designers
    // see the correct state while editing the widget Blueprint.
    RefreshSelectionVisuals();
}

void UActionSlot::SetAbility(const UAbilityDefinition* InDefinition)
{
    UE_LOG(LogNevergone, Log,
        TEXT("[ActionSlot] SetAbility: %s"),
        InDefinition ? *InDefinition->DisplayName.ToString() : TEXT("(none)"));

    BoundDefinition = InDefinition;
    RefreshIcon();
}

void UActionSlot::SetSelected(bool bSelected)
{
    if (bIsSelected == bSelected)
    {
        return;
    }

    bIsSelected = bSelected;

    UE_LOG(LogNevergone, Verbose,
        TEXT("[ActionSlot] SetSelected: '%s' → %s"),
        BoundDefinition ? *BoundDefinition->DisplayName.ToString() : TEXT("(empty)"),
        bIsSelected ? TEXT("SELECTED") : TEXT("IDLE"));

    RefreshSelectionVisuals();
}

// ---- Private helpers -------------------------------------------------------

void UActionSlot::RefreshIcon()
{
    if (!SlotImage)
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[ActionSlot] RefreshIcon: SlotImage binding is missing — check the widget Blueprint."));
        return;
    }

    UTexture2D* IconTexture = nullptr;

    if (BoundDefinition && BoundDefinition->Icon)
    {
        IconTexture = BoundDefinition->Icon;
    }
    else if (FallbackIcon)
    {
        IconTexture = FallbackIcon;
    }

    if (IconTexture)
    {
        SlotImage->SetBrushFromTexture(IconTexture, /*bMatchSize=*/false);
        SlotImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
    }
    else
    {
        SlotImage->SetVisibility(ESlateVisibility::Hidden);

        UE_LOG(LogNevergone, Warning,
            TEXT("[ActionSlot] RefreshIcon: no icon for '%s' and no FallbackIcon set."),
            BoundDefinition ? *BoundDefinition->DisplayName.ToString() : TEXT("(none)"));
    }
}

void UActionSlot::RefreshSelectionVisuals()
{
    // ---- Border tint ----
    // UBorder::SetBrushColor changes the background/frame color of the border widget.
    // This is the correct API — UOverlay does not have a SetBrushColor or equivalent.
    if (SlotBorder)
    {
        const FLinearColor TargetColor = bIsSelected ? SelectedBorderColor : IdleBorderColor;
        SlotBorder->SetBrushColor(TargetColor);
    }
    else
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[ActionSlot] RefreshSelectionVisuals: SlotBorder binding is missing — check the widget Blueprint."));
    }

    // ---- Ability name label ----
    if (AbilityNameText)
    {
        if (bIsSelected && BoundDefinition)
        {
            AbilityNameText->SetText(BoundDefinition->DisplayName);
            AbilityNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
        }
        else
        {
            AbilityNameText->SetVisibility(ESlateVisibility::Collapsed);
        }
    }
    else
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[ActionSlot] RefreshSelectionVisuals: AbilityNameText binding is missing — check the widget Blueprint."));
    }
}