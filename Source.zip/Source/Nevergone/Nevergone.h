// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NativeGameplayTags.h"

/** Main log category used across the project */
DECLARE_LOG_CATEGORY_EXTERN(LogNevergone, Log, All);

// ---------------------------------------------------------------------------
// Native Gameplay Tags
// They are available project-wide and guaranteed to exist
// before any CDO or static initializer calls RequestGameplayTag().
// ---------------------------------------------------------------------------

// Ability identity tags
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Attack_Melee)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Attack_Ranged)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Attack_Magical)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Heal_Melee)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Heal_Ranged)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Heal_AoE)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Ability_Move)

// Activation requirement tags
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Mode_Combat)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_Turn_CanAct)

// State tags
//Debuffs
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Stunned)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Silenced)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Charmed)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Rooted)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Bleeding)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Poisoned)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Slowed)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_STR_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_CON_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_DEX_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_FOC_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_KNW_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_TEC_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_EVS_Down)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_SPD_Down)

//Buffs
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Regen)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Shielded)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Haste)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Respite)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_Cure)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_STR_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_CON_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_DEX_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_FOC_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_KNW_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_TEC_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_EVS_Up)
UE_DECLARE_GAMEPLAY_TAG_EXTERN(TAG_State_SPD_Up)
