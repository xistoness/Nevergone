// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Interfaces/SaveParticipant.h"
#include "Types/BattleTypes.h"
#include "Types/UnitAttributeTypes.h"
#include "UnitStatsComponent.generated.h"

class UUnitDefinition;
struct FBattleUnitState;

DECLARE_MULTICAST_DELEGATE_OneParam(FOnUnitDeath, ACharacterBase*);

// The 8 base attributes distributed by the player on level-up.
// These are persisted and drive concrete stat calculations.
// Equipment bonuses and future modifiers will be separate fields.
USTRUCT(BlueprintType)
struct FUnitAttributes
{
    GENERATED_BODY()

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Constitution = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Strength = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Dexterity = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Knowledge = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Focus = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Technique = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Evasiveness = 1;

    UPROPERTY(SaveGame, EditDefaultsOnly, BlueprintReadOnly)
    int32 Speed = 1;
};

// GetAttributeValue — defined here (after FUnitAttributes) so the body can
// reference struct fields. EUnitAttribute is declared in UnitAttributeTypes.h.
inline int32 GetAttributeValue(const FUnitAttributes& Attrs, EUnitAttribute Attr)
{
    switch (Attr)
    {
    case EUnitAttribute::Constitution:  return Attrs.Constitution;
    case EUnitAttribute::Strength:      return Attrs.Strength;
    case EUnitAttribute::Dexterity:     return Attrs.Dexterity;
    case EUnitAttribute::Knowledge:     return Attrs.Knowledge;
    case EUnitAttribute::Focus:         return Attrs.Focus;
    case EUnitAttribute::Technique:     return Attrs.Technique;
    case EUnitAttribute::Evasiveness:   return Attrs.Evasiveness;
    case EUnitAttribute::Speed:         return Attrs.Speed;
    default:                            return 0;
    }
}

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class NEVERGONE_API UUnitStatsComponent : public UActorComponent, public ISaveParticipant
{
    GENERATED_BODY()

public:
    UUnitStatsComponent();
    void InitializeForBattle();

    // ===== Save =====
    virtual void WriteSaveData_Implementation(FActorSaveData& OutData) const override;
    virtual void ReadSaveData_Implementation(const FActorSaveData& InData) override;

    // ===== Definition =====
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    UUnitDefinition* Definition;

    // ===== Persistent State =====

    UPROPERTY(SaveGame)
    int32 Level = 1;

    // HP is persisted because it carries between exploration and battle.
    // Other derived stats are recomputed each battle from attributes + definition.
    UPROPERTY(SaveGame)
    int32 PersistentHP = 0;

    // The 8 base attributes invested by the player over level-ups.
    UPROPERTY(SaveGame)
    FUnitAttributes Attributes;

    // Temporary attribute bonuses from active status effects (IncreaseStat/DecreaseStat).
    // Persisted so mid-combat saves restore the correct effective values.
    // Zeroed at the start of each battle via ResetTemporaryBonuses().
    UPROPERTY(SaveGame)
    FUnitAttributes TemporaryAttributeBonuses;

    // Resets all temporary bonuses to zero — called at battle start.
    void ResetTemporaryBonuses();

    // ===== Battle Session State =====
    // These are reset/assigned by CombatManager at battle start.
    // They are NOT persisted — BattleUnitState is the authority during combat.

    UPROPERTY(SaveGame)
    int32 AllyTeam = 0;

    UPROPERTY(SaveGame)
    int32 EnemyTeam = 1;

    UPROPERTY()
    int32 CurrentActionPoints = 0;

    // ===== Getters — persistent =====
    int32 GetAllyTeam() const;
    int32 GetEnemyTeam() const;
    int32 GetCurrentHP() const;
    bool IsAlive() const;
    const UUnitDefinition* GetDefinition() const { return Definition; }
    FGridTraversalParams GetTraversalParams() const;

    // ===== Getters — concrete stats derived from attributes + definition =====
    // These are used to POPULATE BattleUnitState at battle start.
    // During combat, read from BattleUnitState instead.
    int32 GetMaxHP() const;
    int32 GetPhysicalAttack() const;
    int32 GetRangedAttack() const;
    int32 GetMagicalPower() const;
    int32 GetPhysicalDefense() const;
    int32 GetMagicalDefense() const;
    int32 GetActionPoints() const;
    int32 GetMovementRange() const;
    int32 GetHitChanceModifier() const;
    int32 GetEvasionModifier() const;
    int32 GetCritChance() const;         // Returns percentage (0-100)

    // Repopulates all derived combat stat fields on OutState from the current
    // effective attributes (Attributes + TemporaryAttributeBonuses).
    // Call this at battle start and after any TemporaryAttributeBonuses change.
    void RecalculateBattleStats(struct FBattleUnitState& OutState) const;

    // ===== Setters =====
    void SetAllyTeam(int32 Team);
    void SetEnemyTeam(int32 Team);

    // Raw HP write — clamps to [0, MaxHP] and fires OnUnitDeath if HP reaches zero.
    // All combat-facing HP changes must go through UCombatEventBus.
    void SetCurrentHP(int32 NewHP);
    void SetCurrentActionPoints(int32 ActionPoints);

    FOnUnitDeath OnUnitDeath;

protected:
    virtual void BeginPlay() override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
};