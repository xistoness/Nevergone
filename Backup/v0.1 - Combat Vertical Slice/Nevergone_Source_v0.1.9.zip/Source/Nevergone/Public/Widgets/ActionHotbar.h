// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ActionHotbar.generated.h"

/**
 * 
 */
UCLASS()
class NEVERGONE_API UActionHotbar : public UUserWidget
{
	GENERATED_BODY()
	
};
