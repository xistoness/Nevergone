// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ActionSlot.generated.h"

/**
 * 
 */
UCLASS()
class NEVERGONE_API UActionSlot : public UUserWidget
{
	GENERATED_BODY()
	
};
