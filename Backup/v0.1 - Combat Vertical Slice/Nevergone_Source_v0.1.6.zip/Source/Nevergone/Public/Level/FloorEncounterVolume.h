// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ActorComponents/SaveableComponent.h"
#include "Interfaces/SaveParticipant.h"
#include "FloorEncounterVolume.generated.h"

class UFloorEncounterData;
class UBoxComponent;
class ABattleVolume;
class USkeletalMeshComponent;

UCLASS()
class NEVERGONE_API AFloorEncounterVolume : public AActor, public ISaveParticipant
{
	GENERATED_BODY()
	
public:	

	AFloorEncounterVolume();
	
	// Save Game functions
	virtual void WriteSaveData_Implementation(FActorSaveData& OutData) const override;
	virtual void ReadSaveData_Implementation(const FActorSaveData& InData) override;
	virtual void OnPostRestore_Implementation() override;
	
	ABattleVolume* GetBattleVolume() const;
	void DeactivateEncounter();

	UPROPERTY(EditAnywhere, Category = "Encounter")
	TObjectPtr<UFloorEncounterData> EncounterData;

	UPROPERTY(EditAnywhere, Category = "Encounter")
	bool bAutoStartOnEnter = true;
	
	UPROPERTY(EditAnywhere, Category="Battle")
	ABattleVolume* BattleVolume;

	UPROPERTY()
	bool bEncounterResolved = false;
	

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Encounter")
	TObjectPtr<UBoxComponent> TriggerBox;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Encounter")
	USkeletalMeshComponent* SkeletalMeshComponent;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Save")
	USaveableComponent* SaveableComponent;

protected:
	UFUNCTION()
	void OnTriggerBeginOverlap(
		UPrimitiveComponent* OverlappedComponent,
		AActor* OtherActor,
		UPrimitiveComponent* OtherComp,
		int32 OtherBodyIndex,
		bool bFromSweep,
		const FHitResult& SweepResult
	);
};
