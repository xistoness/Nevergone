// Copyright Xyzto Works


#include "Level/FloorEncounterVolume.h"
#include "Level/BattleVolume.h"
#include "Components/BoxComponent.h"
#include "Data/ActorSaveData.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "GameInstance/MyGameInstance.h"
#include "GameInstance/GameContextManager.h"
#include "GameInstance/SaveKeys.h"
#include "Engine/World.h"

AFloorEncounterVolume::AFloorEncounterVolume()
{
	PrimaryActorTick.bCanEverTick = false;
	TriggerBox = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerBox"));
	SetRootComponent(TriggerBox);

	// --- Collision setup ---
	TriggerBox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	TriggerBox->SetCollisionObjectType(ECC_WorldDynamic);
	TriggerBox->SetCollisionResponseToAllChannels(ECR_Ignore);
	TriggerBox->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);

	TriggerBox->SetGenerateOverlapEvents(true);
	TriggerBox->SetBoxExtent(FVector(200.f, 200.f, 200.f));

	TriggerBox->OnComponentBeginOverlap.AddDynamic(
		this,
		&AFloorEncounterVolume::OnTriggerBeginOverlap
	);
	
	SkeletalMeshComponent = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("SkeletalMeshComponent"));
	SkeletalMeshComponent->SetupAttachment(RootComponent);
	
	SaveableComponent = CreateDefaultSubobject<USaveableComponent>(TEXT("SaveableComponent"));
}

void AFloorEncounterVolume::WriteSaveData_Implementation(FActorSaveData& OutData) const
{
	FSavePayload Payload;
	FMemoryWriter Writer(Payload.Data, true);
	FArchive& Ar = Writer;

	bool TempResolved = bEncounterResolved;
	Ar << TempResolved;

	OutData.CustomDataMap.Add(SaveKeys::EncounterVolume, MoveTemp(Payload));
}

void AFloorEncounterVolume::ReadSaveData_Implementation(const FActorSaveData& InData)
{
	const FSavePayload* Payload = InData.CustomDataMap.Find(SaveKeys::EncounterVolume);
	if (!Payload) return;

	FMemoryReader Reader(Payload->Data, true);
	FArchive& Ar = Reader;

	Ar << bEncounterResolved;
}

void AFloorEncounterVolume::OnPostRestore_Implementation()
{
	// State is already in bEncounterResolved from ReadSaveData.
	// Apply the visual/collision consequences here, after the world is fully loaded.
	if (bEncounterResolved)
	{
		DeactivateEncounter();
	}
}

ABattleVolume* AFloorEncounterVolume::GetBattleVolume() const
{
	return BattleVolume;
}

void AFloorEncounterVolume::DeactivateEncounter()
{
	bEncounterResolved = true;

	SetActorEnableCollision(false);
	SetActorHiddenInGame(true);

	bAutoStartOnEnter = false;
}

void AFloorEncounterVolume::OnTriggerBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
                                                  UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!bAutoStartOnEnter || !EncounterData || bEncounterResolved)
	{
		return;
	}

	if (!OtherActor)
	{
		return;
	}

	// Only player-controlled pawns can trigger encounters
	const APawn* Pawn = Cast<APawn>(OtherActor);
	if (!Pawn || !Pawn->IsPlayerControlled())
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	UGameInstance* GameInstance = World->GetGameInstance();
	if (!GameInstance)
	{
		return;
	}

	UGameContextManager* ContextManager =
		GameInstance->GetSubsystem<UGameContextManager>();

	if (!ContextManager)
	{
		return;
	}

	ContextManager->RequestBattlePreparation(this);
	
	if (!SkeletalMeshComponent)
	{
		return;
	}
	SkeletalMeshComponent->SetVisibility(false);
}
