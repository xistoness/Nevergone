// Copyright Xyzto Works

#include "GameMode/Combat/StatusEffectManager.h"

#include "AbilitySystemComponent.h"
#include "Characters/CharacterBase.h"
#include "Data/StatusEffectDefinition.h"
#include "GameMode/Combat/BattleState.h"
#include "GameMode/Combat/BattleUnitState.h"
#include "GameMode/Combat/CombatEventBus.h"
#include "GameMode/TurnManager.h"
#include "Nevergone.h"

// ---------------------------------------------------------------------------
// Lifecycle
// ---------------------------------------------------------------------------

void UStatusEffectManager::Initialize(
    UBattleState*    InBattleState,
    UCombatEventBus* InEventBus,
    UTurnManager*    InTurnManager
)
{
    BattleState = InBattleState;
    EventBus    = InEventBus;
    TurnManager = InTurnManager;

    TurnStateHandle = TurnManager->OnTurnStateChanged.AddUObject(
        this, &UStatusEffectManager::OnTurnStateChanged
    );

    UE_LOG(LogNevergone, Log, TEXT("[StatusEffectManager] Initialized"));
}

void UStatusEffectManager::Shutdown()
{
    if (TurnStateHandle.IsValid() && TurnManager)
    {
        TurnManager->OnTurnStateChanged.Remove(TurnStateHandle);
        TurnStateHandle.Reset();
    }

    UE_LOG(LogNevergone, Log, TEXT("[StatusEffectManager] Shutdown"));
}

// ---------------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------------

void UStatusEffectManager::ApplyStatusEffect(
    ACharacterBase*          Caster,
    ACharacterBase*          Target,
    UStatusEffectDefinition* Definition
)
{
    if (!Target || !Definition)
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[StatusEffectManager] ApplyStatusEffect: null Target or Definition — skipped"));
        return;
    }

    FBattleUnitState* TargetState = BattleState->FindUnitState(Target);
    if (!TargetState || TargetState->bIsDead)
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[StatusEffectManager] ApplyStatusEffect: no live BattleUnitState for %s — skipped"),
            *GetNameSafe(Target));
        return;
    }

    if (IsImmune(Target, Definition))
    {
        UE_LOG(LogNevergone, Log,
            TEXT("[StatusEffectManager] %s is immune to '%s' — skipped"),
            *GetNameSafe(Target), *Definition->DisplayName.ToString());
        return;
    }

    const FGameplayTag& Tag = Definition->StatusTag;

    // --- Handle stack behavior for existing instances ---
    const int32 ExistingIndex = TargetState->ActiveStatusEffects.IndexOfByPredicate(
        [&Tag](const FActiveStatusEffect& E)
        {
            return E.Definition && E.Definition->StatusTag == Tag;
        }
    );

    const bool bHasExisting = ExistingIndex != INDEX_NONE;

    if (bHasExisting)
    {
        switch (Definition->StackBehavior)
        {
            case EStatusStackBehavior::Ignore:
                UE_LOG(LogNevergone, Log,
                    TEXT("[StatusEffectManager] '%s' on %s already active — ignoring re-application"),
                    *Tag.ToString(), *GetNameSafe(Target));
                return;

            case EStatusStackBehavior::Refresh:
                TargetState->ActiveStatusEffects[ExistingIndex].TurnsRemaining = Definition->DurationTurns;
                UE_LOG(LogNevergone, Log,
                    TEXT("[StatusEffectManager] '%s' on %s refreshed to %d turns"),
                    *Tag.ToString(), *GetNameSafe(Target), Definition->DurationTurns);
                return;

            case EStatusStackBehavior::Stack:
                // Fall through to create a new independent instance
                break;
        }
    }

    // --- Build the new instance ---
    FActiveStatusEffect NewInstance;
    NewInstance.Definition     = Definition;
    NewInstance.Caster         = Caster;
    NewInstance.TurnsRemaining = Definition->DurationTurns;
    NewInstance.InstanceId     = GenerateInstanceId();

    if (Caster)
    {
        const FBattleUnitState* CasterState = BattleState->FindUnitState(Caster);
        if (CasterState)
        {
            NewInstance.CasterTeam = CasterState->Team;

            // Cache the relevant caster stat so per-tick damage survives caster death
            if (Definition->TickFormula == EStatusTickFormula::PercentOfCasterStat)
            {
                switch (Definition->TickStatSource)
                {
                    case EStatusTickStatSource::MagicalPower:
                        NewInstance.CachedCasterStatValue = CasterState->MagicalPower;   break;
                    case EStatusTickStatSource::PhysicalAttack:
                        NewInstance.CachedCasterStatValue = CasterState->PhysicalAttack; break;
                    case EStatusTickStatSource::RangedAttack:
                        NewInstance.CachedCasterStatValue = CasterState->RangedAttack;   break;
                }
            }
        }
    }

    // Add to list before ApplyPassiveEffect so Shield can read MagicalPower from CasterState
    TargetState->ActiveStatusEffects.Add(NewInstance);
    FActiveStatusEffect& StoredInstance = TargetState->ActiveStatusEffects.Last();

    // --- Apply passive (stat mod, shield, charm, etc.) ---
    ApplyPassiveEffect(Target, StoredInstance);

    // --- Grant ASC tag (first instance only — tag is per-unit, not per-stack) ---
    if (!bHasExisting && Tag.IsValid())
    {
        if (UAbilitySystemComponent* ASC = Target->GetAbilitySystemComponent())
        {
            ASC->AddLooseGameplayTags(FGameplayTagContainer(Tag));
        }
    }

    // --- Notify event bus (floating text, audio, delegates) ---
    if (EventBus)
    {
        EventBus->NotifyStatusApplied(Target, Tag, Definition->DisplayLabel, Definition->Icon);
    }

    UE_LOG(LogNevergone, Log,
        TEXT("[StatusEffectManager] Applied '%s' to %s by %s — %d turns, instanceId=%d"),
        *Tag.ToString(), *GetNameSafe(Target), *GetNameSafe(Caster),
        Definition->DurationTurns, StoredInstance.InstanceId);
}

// ---------------------------------------------------------------------------
// Removal
// ---------------------------------------------------------------------------

void UStatusEffectManager::RemoveStatusEffect(ACharacterBase* Target, const FGameplayTag& StatusTag)
{
    if (!Target) { return; }

    FBattleUnitState* TargetState = BattleState->FindUnitState(Target);
    if (!TargetState) { return; }

    TArray<int32> IdsToRemove;
    for (const FActiveStatusEffect& Instance : TargetState->ActiveStatusEffects)
    {
        if (Instance.Definition && Instance.Definition->StatusTag == StatusTag)
        {
            IdsToRemove.Add(Instance.InstanceId);
        }
    }

    if (IdsToRemove.IsEmpty())
    {
        UE_LOG(LogNevergone, Verbose,
            TEXT("[StatusEffectManager] RemoveStatusEffect: '%s' not found on %s"),
            *StatusTag.ToString(), *GetNameSafe(Target));
        return;
    }

    for (int32 Id : IdsToRemove)
    {
        RemoveStatusEffectInstance(Target, Id);
    }

    UE_LOG(LogNevergone, Log,
        TEXT("[StatusEffectManager] Removed %d instance(s) of '%s' from %s"),
        IdsToRemove.Num(), *StatusTag.ToString(), *GetNameSafe(Target));
}

void UStatusEffectManager::RemoveStatusEffectInstance(ACharacterBase* Target, int32 InstanceId)
{
    if (!Target) { return; }

    FBattleUnitState* TargetState = BattleState->FindUnitState(Target);
    if (!TargetState) { return; }

    const int32 Index = TargetState->ActiveStatusEffects.IndexOfByPredicate(
        [InstanceId](const FActiveStatusEffect& E) { return E.InstanceId == InstanceId; }
    );

    if (Index == INDEX_NONE)
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[StatusEffectManager] RemoveStatusEffectInstance: id=%d not found on %s"),
            InstanceId, *GetNameSafe(Target));
        return;
    }

    const FActiveStatusEffect InstanceCopy = TargetState->ActiveStatusEffects[Index];
    const FGameplayTag Tag = InstanceCopy.Definition
        ? InstanceCopy.Definition->StatusTag
        : FGameplayTag();

    RevertPassiveEffect(Target, InstanceCopy);
    TargetState->ActiveStatusEffects.RemoveAt(Index);

    // Remove the ASC tag only when no other instances of this status remain
    const bool bOtherInstancesExist = TargetState->ActiveStatusEffects.ContainsByPredicate(
        [&Tag](const FActiveStatusEffect& E)
        {
            return E.Definition && E.Definition->StatusTag == Tag;
        }
    );

    if (!bOtherInstancesExist && Tag.IsValid())
    {
        if (UAbilitySystemComponent* ASC = Target->GetAbilitySystemComponent())
        {
            ASC->RemoveLooseGameplayTags(FGameplayTagContainer(Tag));
        }

        if (EventBus)
        {
            EventBus->NotifyStatusCleared(Target, Tag);
        }

        UE_LOG(LogNevergone, Log,
            TEXT("[StatusEffectManager] '%s' fully cleared from %s"),
            *Tag.ToString(), *GetNameSafe(Target));
    }
}

// ---------------------------------------------------------------------------
// Shield
// ---------------------------------------------------------------------------

int32 UStatusEffectManager::AbsorbDamageWithShield(ACharacterBase* Target, int32 IncomingDamage)
{
    if (!Target || IncomingDamage <= 0) { return IncomingDamage; }

    FBattleUnitState* State = BattleState->FindUnitState(Target);
    if (!State) { return IncomingDamage; }

    int32 RemainingDamage = IncomingDamage;
    TArray<int32> DepletedIds;

    for (FActiveStatusEffect& Instance : State->ActiveStatusEffects)
    {
        if (Instance.ShieldHP <= 0 || RemainingDamage <= 0) { continue; }

        const int32 Absorbed = FMath::Min(Instance.ShieldHP, RemainingDamage);
        Instance.ShieldHP   -= Absorbed;
        RemainingDamage     -= Absorbed;

        UE_LOG(LogNevergone, Log,
            TEXT("[StatusEffectManager] Shield on %s absorbed %d — %d shield HP left, %d passed through"),
            *GetNameSafe(Target), Absorbed, Instance.ShieldHP, RemainingDamage);

        if (Instance.ShieldHP <= 0)
        {
            DepletedIds.Add(Instance.InstanceId);
        }
    }

    for (int32 Id : DepletedIds)
    {
        UE_LOG(LogNevergone, Log,
            TEXT("[StatusEffectManager] Shield depleted on %s (instanceId=%d)"),
            *GetNameSafe(Target), Id);
        RemoveStatusEffectInstance(Target, Id);
    }

    return RemainingDamage;
}

// ---------------------------------------------------------------------------
// Queries
// ---------------------------------------------------------------------------

bool UStatusEffectManager::HasStatusEffect(
    const ACharacterBase* Target,
    const FGameplayTag&   StatusTag
) const
{
    if (!Target || !BattleState) { return false; }

    const FBattleUnitState* State =
        BattleState->FindUnitState(const_cast<ACharacterBase*>(Target));
    if (!State) { return false; }

    return State->ActiveStatusEffects.ContainsByPredicate(
        [&StatusTag](const FActiveStatusEffect& E)
        {
            return E.Definition && E.Definition->StatusTag == StatusTag;
        }
    );
}

int32 UStatusEffectManager::GetShieldHP(const ACharacterBase* Target) const
{
    if (!Target || !BattleState) { return 0; }

    const FBattleUnitState* State =
        BattleState->FindUnitState(const_cast<ACharacterBase*>(Target));
    if (!State) { return 0; }

    int32 Total = 0;
    for (const FActiveStatusEffect& Instance : State->ActiveStatusEffects)
    {
        Total += Instance.ShieldHP;
    }
    return Total;
}

// ---------------------------------------------------------------------------
// Turn tick
// ---------------------------------------------------------------------------

void UStatusEffectManager::OnTurnStateChanged(EBattleTurnOwner NewOwner, EBattleTurnPhase NewPhase)
{
    const bool bIsPlayerTurnStart =
        (NewOwner == EBattleTurnOwner::Player && NewPhase == EBattleTurnPhase::AwaitingOrders);
    const bool bIsEnemyTurnStart =
        (NewOwner == EBattleTurnOwner::Enemy && NewPhase == EBattleTurnPhase::ExecutingActions);

    if (!bIsPlayerTurnStart && !bIsEnemyTurnStart) { return; }

    const EBattleUnitTeam ActiveTeam =
        bIsPlayerTurnStart ? EBattleUnitTeam::Ally : EBattleUnitTeam::Enemy;

    UE_LOG(LogNevergone, Log,
        TEXT("[StatusEffectManager] Turn start — ticking statuses for %s team"),
        ActiveTeam == EBattleUnitTeam::Ally ? TEXT("Ally") : TEXT("Enemy"));

    // Victim-timed ticks: fire for units whose own turn is starting
    TickStatusesForTiming(EStatusTickTiming::StartOfVictimTurn, ActiveTeam);

    // Caster-timed ticks: fire for effects whose caster's team turn is starting
    TickStatusesForTiming(EStatusTickTiming::StartOfCasterTurn, ActiveTeam);

    // Expire stale statuses once per full round (player turn start only)
    if (bIsPlayerTurnStart)
    {
        DecrementAndExpireStatuses();
    }
}

void UStatusEffectManager::TickStatusesForTiming(EStatusTickTiming Timing, EBattleUnitTeam ActiveTeam)
{
    if (!BattleState) { return; }

    for (const FBattleUnitState& UnitState : BattleState->GetAllUnitStates())
    {
        if (UnitState.bIsDead) { continue; }

        ACharacterBase* Unit = UnitState.UnitActor.Get();
        if (!Unit) { continue; }

        // GetAllUnitStates returns const refs; we need mutable access for tick mutations
        FBattleUnitState* MutableState = BattleState->FindUnitState(Unit);
        if (!MutableState) { continue; }

        for (FActiveStatusEffect& Instance : MutableState->ActiveStatusEffects)
        {
            if (!Instance.IsValid()) { continue; }
            if (Instance.Definition->TickTiming != Timing) { continue; }
            if (Instance.Definition->TickEffect == EStatusTickEffect::None) { continue; }

            const bool bShouldTick =
                (Timing == EStatusTickTiming::StartOfVictimTurn && UnitState.Team == ActiveTeam) ||
                (Timing == EStatusTickTiming::StartOfCasterTurn && Instance.CasterTeam == ActiveTeam);

            if (bShouldTick)
            {
                TickEffectInstance(Unit, Instance);
            }
        }
    }
}

void UStatusEffectManager::TickEffectInstance(ACharacterBase* Target, FActiveStatusEffect& Instance)
{
    if (!Instance.IsValid() || !EventBus) { return; }

    const float Amount = ResolveTickAmount(Target, Instance);
    if (Amount <= 0.f) { return; }

    const int32 IntAmount = FMath::Max(1, FMath::RoundToInt(Amount));

    switch (Instance.Definition->TickEffect)
    {
        case EStatusTickEffect::DamagePerTurn:
            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Tick '%s': %d damage to %s"),
                *Instance.Definition->StatusTag.ToString(), IntAmount, *GetNameSafe(Target));
            EventBus->NotifyDamageApplied(Instance.Caster.Get(), Target, IntAmount);
            break;

        case EStatusTickEffect::HealPerTurn:
            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Tick '%s': %d heal on %s"),
                *Instance.Definition->StatusTag.ToString(), IntAmount, *GetNameSafe(Target));
            EventBus->NotifyHealApplied(Instance.Caster.Get(), Target, IntAmount);
            break;

        default:
            break;
    }
}

void UStatusEffectManager::DecrementAndExpireStatuses()
{
    if (!BattleState) { return; }

    for (const FBattleUnitState& UnitState : BattleState->GetAllUnitStates())
    {
        ACharacterBase* Unit = UnitState.UnitActor.Get();
        if (!Unit) { continue; }

        FBattleUnitState* MutableState = BattleState->FindUnitState(Unit);
        if (!MutableState) { continue; }

        TArray<int32> ExpiredIds;

        for (FActiveStatusEffect& Instance : MutableState->ActiveStatusEffects)
        {
            if (!Instance.IsValid()) { continue; }

            // TurnsRemaining == 0 means permanent — never decrement
            if (Instance.TurnsRemaining == 0) { continue; }

            Instance.TurnsRemaining--;

            UE_LOG(LogNevergone, Verbose,
                TEXT("[StatusEffectManager] '%s' on %s — %d turns remaining"),
                *Instance.Definition->StatusTag.ToString(),
                *GetNameSafe(Unit),
                Instance.TurnsRemaining);

            if (Instance.TurnsRemaining <= 0)
            {
                ExpiredIds.Add(Instance.InstanceId);
            }
        }

        for (int32 Id : ExpiredIds)
        {
            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Status expired on %s (instanceId=%d)"),
                *GetNameSafe(Unit), Id);
            RemoveStatusEffectInstance(Unit, Id);
        }
    }
}

// ---------------------------------------------------------------------------
// Passive effect helpers
// ---------------------------------------------------------------------------

void UStatusEffectManager::ApplyPassiveEffect(ACharacterBase* Target, FActiveStatusEffect& Instance)
{
    if (!Instance.IsValid() || !BattleState) { return; }

    FBattleUnitState* State = BattleState->FindUnitState(Target);
    if (!State) { return; }

    switch (Instance.Definition->PassiveEffect)
    {
        case EStatusPassiveEffect::ReduceMovementRangePercent:
        {
            // Compute penalty from the CURRENT MovementRange so that the exact same
            // value can be added back on revert without storing the original.
            // Non-stacking: Refresh reuses the same instance so this only runs once.
            const int32 Penalty = FMath::Max(1, FMath::RoundToInt(
                State->MovementRange * Instance.Definition->MovementRangeModifierPercent
            ));
            State->MovementRange = FMath::Max(1, State->MovementRange - Penalty);

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Slow on %s — MovementRange reduced by %d (now %d)"),
                *GetNameSafe(Target), Penalty, State->MovementRange);
            break;
        }

        case EStatusPassiveEffect::IncreaseMovementRangePercent:
        {
            const int32 Bonus = FMath::Max(1, FMath::RoundToInt(
                State->MovementRange * Instance.Definition->MovementRangeModifierPercent
            ));
            State->MovementRange += Bonus;

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Haste on %s — MovementRange increased by %d (now %d)"),
                *GetNameSafe(Target), Bonus, State->MovementRange);
            break;
        }

        case EStatusPassiveEffect::Shield:
        {
            // Populate CachedCasterStatValue if not already set (terrain sources may have no caster)
            if (Instance.CachedCasterStatValue <= 0)
            {
                if (const FBattleUnitState* CasterState = BattleState->FindUnitState(Instance.Caster.Get()))
                {
                    Instance.CachedCasterStatValue = CasterState->MagicalPower;
                }
            }

            Instance.ShieldHP = FMath::Max(1, FMath::RoundToInt(
                Instance.CachedCasterStatValue * Instance.Definition->ShieldMultiplier
            ));

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Shield on %s — %d HP"),
                *GetNameSafe(Target), Instance.ShieldHP);
            break;
        }

        case EStatusPassiveEffect::GrantActionPoints:
        {
            State->CurrentActionPoints += Instance.Definition->BonusActionPoints;

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Respite on %s — +%d AP (now %d)"),
                *GetNameSafe(Target), Instance.Definition->BonusActionPoints, State->CurrentActionPoints);
            break;
        }

        case EStatusPassiveEffect::CleansesStatuses:
            ApplyCleanse(Target, Instance);
            break;

        case EStatusPassiveEffect::SwitchTeam:
        {
            // Charm: flip the unit's BattleState team so TurnManager and AI include it correctly.
            // The original team is implicitly the opposite of whatever it becomes here;
            // RevertPassiveEffect simply flips again to restore it.
            const EBattleUnitTeam Original = State->Team;
            State->Team = (Original == EBattleUnitTeam::Ally)
                ? EBattleUnitTeam::Enemy
                : EBattleUnitTeam::Ally;

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Charm on %s — team flipped %s -> %s"),
                *GetNameSafe(Target),
                Original     == EBattleUnitTeam::Ally ? TEXT("Ally") : TEXT("Enemy"),
                State->Team  == EBattleUnitTeam::Ally ? TEXT("Ally") : TEXT("Enemy"));
            break;
        }

        default:
            break;
    }
}

void UStatusEffectManager::RevertPassiveEffect(
    ACharacterBase*             Target,
    const FActiveStatusEffect&  Instance
)
{
    if (!Instance.IsValid() || !BattleState) { return; }

    FBattleUnitState* State = BattleState->FindUnitState(Target);
    if (!State) { return; }

    switch (Instance.Definition->PassiveEffect)
    {
        case EStatusPassiveEffect::ReduceMovementRangePercent:
        {
            // Reverse: divide by (1 - percent) to recover the pre-penalty value exactly.
            const float Pct      = Instance.Definition->MovementRangeModifierPercent;
            const float Divisor  = FMath::Max(0.01f, 1.f - Pct);
            State->MovementRange = FMath::RoundToInt(State->MovementRange / Divisor);

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Slow removed from %s — MovementRange restored to %d"),
                *GetNameSafe(Target), State->MovementRange);
            break;
        }

        case EStatusPassiveEffect::IncreaseMovementRangePercent:
        {
            const float Pct      = Instance.Definition->MovementRangeModifierPercent;
            const float Divisor  = 1.f + Pct;
            State->MovementRange = FMath::RoundToInt(State->MovementRange / Divisor);

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Haste removed from %s — MovementRange restored to %d"),
                *GetNameSafe(Target), State->MovementRange);
            break;
        }

        case EStatusPassiveEffect::SwitchTeam:
        {
            // Charm expiry: flip team back
            const EBattleUnitTeam Current = State->Team;
            State->Team = (Current == EBattleUnitTeam::Ally)
                ? EBattleUnitTeam::Enemy
                : EBattleUnitTeam::Ally;

            UE_LOG(LogNevergone, Log,
                TEXT("[StatusEffectManager] Charm removed from %s — team restored to %s"),
                *GetNameSafe(Target),
                State->Team == EBattleUnitTeam::Ally ? TEXT("Ally") : TEXT("Enemy"));
            break;
        }

        // Shield: HP already zeroed by AbsorbDamageWithShield or natural expiry — nothing to revert.
        // GrantActionPoints: AP was consumed during the turn; not taken back on expiry by design.
        // CleansesStatuses: one-shot effect; nothing to revert.
        default:
            break;
    }
}

void UStatusEffectManager::ApplyCleanse(ACharacterBase* Target, FActiveStatusEffect& Instance)
{
    if (!Instance.IsValid()) { return; }

    UE_LOG(LogNevergone, Log,
        TEXT("[StatusEffectManager] Cure on %s — cleansing %d tag(s)"),
        *GetNameSafe(Target), Instance.Definition->TagsToCleanse.Num());

    for (const FGameplayTag& Tag : Instance.Definition->TagsToCleanse)
    {
        RemoveStatusEffect(Target, Tag);
    }

    // Force immediate expiry: set TurnsRemaining to 1 so DecrementAndExpireStatuses
    // removes this Cure instance at the end of the current turn cycle.
    Instance.TurnsRemaining = 1;
}

// ---------------------------------------------------------------------------
// Immunity
// ---------------------------------------------------------------------------

bool UStatusEffectManager::IsImmune(
    ACharacterBase*          Target,
    const UStatusEffectDefinition* Definition
) const
{
    if (!Target || !Definition) { return false; }

    const UAbilitySystemComponent* ASC = Target->GetAbilitySystemComponent();
    if (!ASC) { return false; }

    // Immunity tag convention: "Immunity." + status tag name with "." replaced by "_"
    // Example: State.Stunned -> Immunity.State_Stunned
    // Any system (UnitDefinition InnateImmunityTags, equipment GEs, terrain) can grant these.
    const FString TagName = Definition->StatusTag.GetTagName().ToString();
    const FString ImmunityName = FString::Printf(TEXT("Immunity.%s"),
        *TagName.Replace(TEXT("."), TEXT("_")));

    const FGameplayTag ImmunityTag = FGameplayTag::RequestGameplayTag(
        FName(*ImmunityName), /*bErrorIfNotFound=*/false
    );

    return ImmunityTag.IsValid() && ASC->HasMatchingGameplayTag(ImmunityTag);
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

float UStatusEffectManager::ResolveTickAmount(
    const ACharacterBase*      Target,
    const FActiveStatusEffect& Instance
) const
{
    if (!Instance.IsValid() || !BattleState) { return 0.f; }

    switch (Instance.Definition->TickFormula)
    {
        case EStatusTickFormula::Flat:
            return Instance.Definition->TickFlatAmount;

        case EStatusTickFormula::PercentOfTargetMaxHP:
        {
            const FBattleUnitState* TargetState =
                BattleState->FindUnitState(const_cast<ACharacterBase*>(Target));
            return TargetState
                ? TargetState->MaxHP * Instance.Definition->TickPercent
                : 0.f;
        }

        case EStatusTickFormula::PercentOfCasterStat:
            return Instance.CachedCasterStatValue * Instance.Definition->TickPercent;
    }

    return 0.f;
}

int32 UStatusEffectManager::GenerateInstanceId()
{
    return NextInstanceId++;
}