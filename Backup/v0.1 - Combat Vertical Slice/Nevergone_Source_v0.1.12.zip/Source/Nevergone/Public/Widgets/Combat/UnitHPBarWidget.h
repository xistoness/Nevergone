// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "UnitHPBarWidget.generated.h"

class ACharacterBase;
class UCombatEventBus;
class UProgressBar;
class UTextBlock;

/**
 * HP bar widget for a single combat unit.
 *
 * This widget is NOT responsible for its own screen-space positioning.
 * The BattleHUDWidget owns a CanvasPanel and updates each bar's slot
 * position every tick via UpdateScreenPosition().
 *
 * This widget is only responsible for:
 *   - Displaying the HP bar and text
 *   - Subscribing to CombatEventBus and updating on damage/heal/death
 *   - Exposing BlueprintImplementableEvents for visual feedback
 */
UCLASS(Abstract)
class NEVERGONE_API UUnitHPBarWidget : public UUserWidget
{
    GENERATED_BODY()

public:

    UFUNCTION(BlueprintCallable, Category = "HP Bar")
    void InitializeForUnit(ACharacterBase* InUnit, UCombatEventBus* InEventBus,
                            int32 MaxHP, int32 CurrentHP);

    UFUNCTION(BlueprintCallable, Category = "HP Bar")
    void Deinitialize();

    UFUNCTION(BlueprintPure, Category = "HP Bar")
    ACharacterBase* GetTrackedUnit() const { return TrackedUnit; }

protected:

    UPROPERTY(meta = (BindWidget))
    TObjectPtr<UProgressBar> HPBar;

    UPROPERTY(meta = (BindWidgetOptional))
    TObjectPtr<UTextBlock> HPText;

    UFUNCTION(BlueprintImplementableEvent, Category = "HP Bar")
    void OnDamageReceived(int32 NewHP, int32 OldHP);

    UFUNCTION(BlueprintImplementableEvent, Category = "HP Bar")
    void OnHealReceived(int32 NewHP, int32 OldHP);

    UFUNCTION(BlueprintImplementableEvent, Category = "HP Bar")
    void OnUnitDied();

private:

    void HandleDamageApplied(ACharacterBase* Source, ACharacterBase* Target, int32 Amount);
    void HandleHealApplied(ACharacterBase* Source, ACharacterBase* Target, int32 Amount);
    void HandleUnitDied(ACharacterBase* Unit);

    // All HP values are int32 — no fractional HP exists in this system
    void RefreshDisplay(int32 NewHP);

    UPROPERTY()
    TObjectPtr<ACharacterBase> TrackedUnit;

    UPROPERTY()
    TObjectPtr<UCombatEventBus> EventBus;

    int32 CachedMaxHP     = 1;
    int32 CachedCurrentHP = 1;

    FDelegateHandle DamageHandle;
    FDelegateHandle HealHandle;
    FDelegateHandle DiedHandle;
};