// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "BattleAIQueryService.generated.h"

/**
 * 
 */
UCLASS()
class NEVERGONE_API UBattleAIQueryService : public UObject
{
	GENERATED_BODY()
	
public:
	TArray<ACharacterBase*> GetAlliedUnitsForTeam(ETwitterOwner Team) const;
	TArray<ACharacterBase*> GetEnemyUnitsForTeam(ETwitterOwner Team) const;

	bool CanUnitStillAct(const ACharacterBase* Unit) const;
	bool IsUnitAlive(const ACharacterBase* Unit) const;

	TArray<FIntPoint> GetReachableTiles(const ACharacterBase* Unit) const;
	TArray<ACharacterBase*> GetValidTargetsForAbility(const ACharacterBase* Unit, TSubclassOf<UBattleGameplayAbility> AbilityClass) const;

	float EstimateDamage(const ACharacterBase* SourceUnit, const ACharacterBase* TargetUnit, TSubclassOf<UBattleGameplayAbility> AbilityClass) const;
	float GetDistanceScore(const ACharacterBase* SourceUnit, const ACharacterBase* TargetUnit) const;

	bool IsTileReserved(const FIntPoint& Tile, const FTeamTurnContext& TurnContext) const;
	float GetReservedDamageForTarget(const ACharacterBase* Target, const FTeamTurnContext& TurnContext) const;
	
};
