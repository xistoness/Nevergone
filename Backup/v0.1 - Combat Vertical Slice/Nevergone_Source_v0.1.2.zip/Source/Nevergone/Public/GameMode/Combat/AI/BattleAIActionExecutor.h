// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "BattleAIActionExecutor.generated.h"

/**
 * 
 */
UCLASS()
class NEVERGONE_API UBattleAIActionExecutor : public UObject
{
	GENERATED_BODY()
	
public:
	bool ExecuteAction(const FTeamCandidateAction& Action);
};
