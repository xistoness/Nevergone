// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "BattleAIComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class NEVERGONE_API UBattleAIComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UBattleAIComponent();
	void GatherCandidateActions(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;

protected:
	// Called when the game starts
	virtual void BeginPlay() override;
	
	void GatherAbilityCandidates(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	void GatherMoveCandidates(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	void GatherEndTurnCandidate(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	float ScoreCandidateAction(FTeamCandidateAction& Candidate, const FTeamTurnContext& TurnContext) const;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

		
};
