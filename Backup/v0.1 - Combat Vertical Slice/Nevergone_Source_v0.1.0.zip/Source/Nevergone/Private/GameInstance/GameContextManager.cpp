// Copyright Xyzto Works


#include "GameInstance/GameContextManager.h"

#include "Characters/CharacterBase.h"
#include "GameMode/TowerFloorGameMode.h"
#include "GameMode/CombatManager.h"
#include "GameMode/BattlePreparationContext.h"
#include "GameMode/BattlefieldLayoutSubsystem.h"
#include "GameMode/BattlefieldQuerySubsystem.h"
#include "Level/EncounterGeneratorSubsystem.h"
#include "Level/FloorEncounterVolume.h"
#include "Level/GridManager.h"
#include "Party/PartyManagerSubsystem.h"

#include "Engine/World.h"
#include "GameMode/BattleResultsContext.h"
#include "Kismet/GameplayStatics.h"


void UGameContextManager::RequestExploration()
{
	if (!CanEnterState(EGameContextState::Exploration))
		return;

	EnterState(EGameContextState::Exploration);
}

void UGameContextManager::RequestBattlePreparation(
	AFloorEncounterVolume* EncounterSource)
{
	UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Requesting battle preparation..."));

	if (!CanEnterState(EGameContextState::BattlePreparation))
		return;

	EnterState(EGameContextState::BattlePreparation);

	// Create grid manager (empty, not initialized yet)
	UGridManager* Grid = GetWorld()->GetSubsystem<UGridManager>();

	// Create battle preparation context
	ActiveBattlePrepContext = NewObject<UBattlePreparationContext>(this);
	ActiveBattlePrepContext->Initialize();

	// Create combat manager
	CreateCombatManager();

	// 1. Generate encounter data
	auto* EncounterGen = GetWorld()->GetSubsystem<UEncounterGeneratorSubsystem>();
	EncounterGen->GenerateEncounter(
		EncounterSource->EncounterData,
		*ActiveBattlePrepContext
	);

	// 2. Generate player party
	auto* PartyManager =
		GetGameInstance()->GetSubsystem<UPartyManagerSubsystem>();

	PartyManager->BuildBattleParty(
		EncounterSource->EncounterData,
		ActiveBattlePrepContext->PlayerParty
	);

	// 3. Generate tactical grid
	if (ABattleVolume* BattleVolume =
		EncounterSource->GetBattleVolume())
	{
		UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Tries to generate grid..."));
		GetWorld()->GetSubsystem<UGridManager>()->GenerateGrid(BattleVolume, GetWorld());
	}

	// 4. Plan battlefield layout
	auto* BattlefieldQuery =
		GetWorld()->GetSubsystem<UBattlefieldQuerySubsystem>();

	BattlefieldQuery->BuildCache();

	auto* Layout =
		GetWorld()->GetSubsystem<UBattlefieldLayoutSubsystem>();

	Layout->PlanSpawns(
		*BattlefieldQuery,
		*ActiveBattlePrepContext
	);

	// 5. Enter preparation phase
	ActiveCombatManager->EnterPreparation(*ActiveBattlePrepContext);

	UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Battle preparation ready!"));
	
	APawn* Pawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);

	if (Pawn)
	{
		ACharacterBase* Character = Cast<ACharacterBase>(Pawn);

		if (Character)
		{
			ActiveBattleSession.bSessionActive = true;
			ActiveBattleSession.ExplorationCharacter = Character;
			ActiveBattleSession.ExplorationCharacterTransform = Character->GetActorTransform();
		}
	}

	ActiveBattleSession.EncounterSource = EncounterSource;

	// Debug auto-start
	RequestBattleStart();
}

void UGameContextManager::AbortBattle()
{
	ActiveCombatManager->CancelPreparation();
	ActiveBattlePrepContext = nullptr;
}

void UGameContextManager::RequestBattleStart()
{
	UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Requesting battle start..."));
	if (!CanEnterState(EGameContextState::Battle))
		return;
	UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Can enter battle state!"));
	if (!ActiveBattlePrepContext ||
		!ActiveBattlePrepContext->IsReadyToStartCombat())
	{
		return;
	}
	UE_LOG(LogTemp, Warning, TEXT("[GameContextManager]: Battle preparation context is ready to start combat!"));

	EnterState(EGameContextState::Battle);

	check(ActiveCombatManager);

	ActiveCombatManager->StartCombat(*ActiveBattlePrepContext);

	// Context is now immutable and discarded
	ActiveBattlePrepContext = nullptr;
}

void UGameContextManager::RequestBattleEnd()
{
	if (ActiveCombatManager)
	{
		ActiveCombatManager->EndCombatWithWinner(EBattleUnitTeam::Enemy);
	}
}

void UGameContextManager::RequestTransition()
{
	EnterState(EGameContextState::Transition);
}

void UGameContextManager::EnterBattleResults()
{
	if (!CanEnterState(EGameContextState::BattleResults))
	{
		return;
	}

	EnterState(EGameContextState::BattleResults);

	UBattleResultsContext* ResultsContext = NewObject<UBattleResultsContext>(this);
	ResultsContext->Initialize(ActiveBattleSession);
	ResultsContext->DumpToLog();

	ReturnToExploration();
}

void UGameContextManager::ReturnToExploration()
{
	if (!CanEnterState(EGameContextState::Exploration))
	{
		return;
	}

	ACharacterBase* Character = ActiveBattleSession.ExplorationCharacter.Get();
	if (Character)
	{
		Character->SetActorHiddenInGame(false);
		Character->SetActorEnableCollision(true);
		Character->SetActorTickEnabled(true);
		Character->SetActorTransform(ActiveBattleSession.ExplorationCharacterTransform);
		Character->EnableExplorationMode();
	}

	EnterState(EGameContextState::Exploration);
}

bool UGameContextManager::CanEnterState(EGameContextState TargetState) const
{
	const ATowerFloorGameMode* FloorGM = GetActiveFloorGameMode();
	if (!FloorGM)
		return false;
	
	switch (TargetState)
	{
	case EGameContextState::Exploration:
		return FloorGM->AllowsExploration();

	case EGameContextState::BattlePreparation:
	case EGameContextState::Battle:
		return FloorGM->AllowsCombat();
	case EGameContextState::BattleResults:

	default:
		return true;
	}
}

void UGameContextManager::EnterState(EGameContextState NewState)
{
	if (CurrentState == NewState)
	{
		return;
	}

	const EGameContextState OldState = CurrentState;

	ExitState(OldState);
	CurrentState = NewState;

	OnGameContextChanged.Broadcast(NewState);
}

void UGameContextManager::ExitState(EGameContextState OldState)
{
	// Destroy / disable systems related to OldState
}

void UGameContextManager::CreateCombatManager()
{
	if (ActiveCombatManager)
	{
		ActiveCombatManager->Cleanup();
		ActiveCombatManager = nullptr;
	}

	ActiveCombatManager = NewObject<UCombatManager>(this);
	ActiveCombatManager->Initialize();
	ActiveCombatManager->OnCombatFinished.AddDynamic(this, &UGameContextManager::HandleCombatFinished);
}

void UGameContextManager::HandleCombatFinished(EBattleUnitTeam WinningTeam)
{
	if (!ActiveCombatManager)
	{
		return;
	}

	ActiveBattleSession.WinningTeam = WinningTeam;
	ActiveBattleSession.bCombatFinished = true;
	ActiveBattleSession.SurvivingAllies = ActiveCombatManager->GetAliveAllies();
	ActiveBattleSession.SurvivingEnemies = ActiveCombatManager->GetAliveEnemies();

	if (ActiveBattleSession.EncounterSource.IsValid())
	{
		ActiveBattleSession.EncounterSource->DeactivateEncounter();
	}

	ActiveCombatManager->Cleanup();
	ActiveCombatManager = nullptr;

	EnterBattleResults();
}

ATowerFloorGameMode* UGameContextManager::GetActiveFloorGameMode() const
{
	if (!GetWorld())
		return nullptr;

	return GetWorld()->GetAuthGameMode<ATowerFloorGameMode>();
}

ACharacterBase* UGameContextManager::GetSavedExplorationCharacter() const
{
	return ActiveBattleSession.ExplorationCharacter.Get();
}

FTransform UGameContextManager::GetSavedExplorationTransform() const
{
	return ActiveBattleSession.ExplorationCharacterTransform;
}

void UGameContextManager::ClearBattleSession()
{
	ActiveBattleSession.Reset();
}