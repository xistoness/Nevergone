// Copyright Xyzto Works

#include "GameMode/Combat/AI/BattleTeamAIPlanner.h"

#include "GameMode/Combat/AI/BattleAIActionExecutor.h"
#include "GameMode/Combat/AI/BattleAIComponent.h"
#include "GameMode/Combat/AI/BattleAIQueryService.h"
#include "GameMode/CombatManager.h"
#include "Level/GridManager.h"
#include "ActorComponents/UnitStatsComponent.h"
#include "Characters/CharacterBase.h"

void UBattleTeamAIPlanner::Initialize(TArray<AActor*>& AllCombatants)
{
	Combatants = AllCombatants;

	QueryService = NewObject<UBattleAIQueryService>(this);
	if (QueryService)
	{
		QueryService->Initialize(AllCombatants);
	}

	ActionExecutor = NewObject<UBattleAIActionExecutor>(this);
	if (ActionExecutor)
	{
		ActionExecutor->Initialize();
		ActionExecutor->OnActionExecutionFinished.AddUObject(this, &UBattleTeamAIPlanner::OnActionExecutionFinished);
	}

	for (AActor* Actor : Combatants)
	{
		ACharacterBase* Unit = Cast<ACharacterBase>(Actor);
		if (!Unit)
		{
			continue;
		}

		UBattleAIComponent* AIComponent = Unit->FindComponentByClass<UBattleAIComponent>();
		if (!AIComponent)
		{
			AIComponent = NewObject<UBattleAIComponent>(Unit, TEXT("BattleAIComponent"));
			if (AIComponent)
			{
				AIComponent->RegisterComponent();
			}
		}

		if (AIComponent)
		{
			AIComponent->Initialize(QueryService);
		}
	}
}

void UBattleTeamAIPlanner::StartTeamTurn()
{
	if (bIsExecutingAction)
	{
		return;
	}

	BuildTurnContext();
	EvaluateNextAction();
}

void UBattleTeamAIPlanner::EvaluateNextAction()
{
	if (bIsExecutingAction)
	{
		return;
	}

	ClearInvalidReservations();
	UpdateFocusTarget();

	TArray<FTeamCandidateAction> Candidates;
	GatherCandidateActions(Candidates);

	FTeamCandidateAction BestAction;
	if (!ChooseBestAction(Candidates, BestAction))
	{
		FinishTeamTurn();
		return;
	}

	if (BestAction.ActionType == ETeamAIActionType::EndTurn || BestAction.Score <= -10.f)
	{
		FinishTeamTurn();
		return;
	}

	ReserveActionConsequences(BestAction);
	bIsExecutingAction = true;

	UE_LOG(LogTemp, Warning, TEXT("[BattleTeamAIPlanner] Chosen action: Unit=%s Type=%d Score=%.2f Reason=%s"),
		*GetNameSafe(BestAction.ActingUnit),
		static_cast<int32>(BestAction.ActionType),
		BestAction.Score,
		*BestAction.Reason);

	if (!ActionExecutor || !ActionExecutor->ExecuteAction(BestAction))
	{
		bIsExecutingAction = false;
		FinishTeamTurn();
	}
}

void UBattleTeamAIPlanner::OnActionExecutionFinished(bool bSuccess)
{
	if (!bIsExecutingAction)
	{
		return;
	}

	bIsExecutingAction = false;

	if (!bSuccess)
	{
		FinishTeamTurn();
		return;
	}

	EvaluateNextAction();
}

void UBattleTeamAIPlanner::FinishTeamTurn()
{
	bIsExecutingAction = false;
	TurnContext.bTurnShouldEnd = true;
	
	UE_LOG(LogTemp, Warning, TEXT("[BattleTeamAIPlanner] Finishing AI team turn"));

	if (UCombatManager* CombatManager = Cast<UCombatManager>(GetOuter()))
	{
		CombatManager->RequestEndEnemyTurn();
	}
}

void UBattleTeamAIPlanner::BuildTurnContext()
{
	TurnContext = FTeamTurnContext();
	if (!QueryService)
	{
		return;
	}

	TurnContext.AlliedUnits = QueryService->GetAlliedUnitsForTeam(EBattleUnitTeam::Enemy);
	TurnContext.EnemyUnits = QueryService->GetEnemyUnitsForTeam(EBattleUnitTeam::Enemy);
}

void UBattleTeamAIPlanner::UpdateFocusTarget()
{
	TurnContext.FocusTarget = nullptr;
	float LowestHP = TNumericLimits<float>::Max();

	for (ACharacterBase* EnemyUnit : TurnContext.EnemyUnits)
	{
		if (!EnemyUnit)
		{
			continue;
		}

		if (const UUnitStatsComponent* Stats = EnemyUnit->GetUnitStats())
		{
			if (Stats->GetCurrentHP() < LowestHP)
			{
				LowestHP = Stats->GetCurrentHP();
				TurnContext.FocusTarget = EnemyUnit;
			}
		}
	}
}

void UBattleTeamAIPlanner::GatherCandidateActions(TArray<FTeamCandidateAction>& OutCandidates)
{
	for (ACharacterBase* AlliedUnit : TurnContext.AlliedUnits)
	{
		if (!AlliedUnit)
		{
			continue;
		}

		if (UBattleAIComponent* AIComponent = AlliedUnit->FindComponentByClass<UBattleAIComponent>())
		{
			AIComponent->GatherCandidateActions(TurnContext, OutCandidates);
		}
	}
}

bool UBattleTeamAIPlanner::ChooseBestAction(const TArray<FTeamCandidateAction>& Candidates, FTeamCandidateAction& OutBestAction) const
{
	if (Candidates.Num() == 0)
	{
		return false;
	}

	const FTeamCandidateAction* BestCandidate = nullptr;
	for (const FTeamCandidateAction& Candidate : Candidates)
	{
		if (!BestCandidate || Candidate.Score > BestCandidate->Score)
		{
			BestCandidate = &Candidate;
		}
	}

	if (!BestCandidate)
	{
		return false;
	}

	OutBestAction = *BestCandidate;
	return true;
}

void UBattleTeamAIPlanner::ReserveActionConsequences(const FTeamCandidateAction& Action)
{
	if (Action.Targeting.TargetActor && Action.ExpectedDamage > 0.f)
	{
		float& ReservedDamage = TurnContext.ReservedDamageByTarget.FindOrAdd(Action.Targeting.TargetActor);
		ReservedDamage += Action.ExpectedDamage;
	}

	if (Action.Targeting.bHasTileTarget)
	{
		TurnContext.ReservedTiles.Add(Action.Targeting.TargetTile);
	}
}

void UBattleTeamAIPlanner::ClearInvalidReservations()
{
	if (Combatants.Num() > 0)
	{
		ACharacterBase* AnyCharacter = Cast<ACharacterBase>(Combatants[0]);
		if (AnyCharacter && AnyCharacter->GetWorld())
		{
			if (UGridManager* Grid = AnyCharacter->GetWorld()->GetSubsystem<UGridManager>())
			{
				for (auto It = TurnContext.ReservedTiles.CreateIterator(); It; ++It)
				{
					if (!Grid->IsValidCoord(*It))
					{
						It.RemoveCurrent();
					}
				}
			}
		}
	}

	for (auto It = TurnContext.ReservedDamageByTarget.CreateIterator(); It; ++It)
	{
		ACharacterBase* Target = It.Key();
		if (!Target || !Target->GetUnitStats() || !Target->GetUnitStats()->IsAlive())
		{
			It.RemoveCurrent();
		}
	}

}
