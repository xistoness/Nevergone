// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Types/AIBattleTypes.h"
#include "Types/BattleTypes.h"
#include "BattleAIComponent.generated.h"

class UBattleAIQueryService;
class UActionResolver;

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class NEVERGONE_API UBattleAIComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBattleAIComponent();

	void Initialize(UBattleAIQueryService* InQueryService);
	void GatherCandidateActions(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;

protected:
	virtual void BeginPlay() override;

	void GatherAbilityCandidates(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	void GatherMoveCandidates(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	void GatherEndTurnCandidate(const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;
	float ScoreCandidateAction(FTeamCandidateAction& Candidate, const FTeamTurnContext& TurnContext) const;

	bool BuildBaseContext(FActionContext& OutContext) const;
	void AddCandidateIfValid(const FActionContext& Context, const FTeamTurnContext& TurnContext, TArray<FTeamCandidateAction>& OutCandidates) const;

public:
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	UPROPERTY()
	UBattleAIQueryService* QueryService = nullptr;

	UPROPERTY()
	UActionResolver* ActionResolver = nullptr;
};
