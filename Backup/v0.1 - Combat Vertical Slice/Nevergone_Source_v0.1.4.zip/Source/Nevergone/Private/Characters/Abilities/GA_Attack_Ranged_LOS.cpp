// Copyright Xyzto Works

#include "Characters/Abilities/GA_Attack_Ranged_LOS.h"

#include "ActorComponents/BattleModeComponent.h"
#include "ActorComponents/UnitStatsComponent.h"
#include "Characters/CharacterBase.h"
#include "Characters/Abilities/TargetingRules/FactionRule.h"
#include "Characters/Abilities/TargetingRules/LineOfSightRule.h"
#include "Characters/Abilities/TargetingRules/RangeRule.h"
#include "Level/GridManager.h"
#include "Types/BattleTypes.h"

UGA_Attack_Ranged_LOS::UGA_Attack_Ranged_LOS()
{
	InstancingPolicy = EGameplayAbilityInstancingPolicy::InstancedPerActor;

	FGameplayTagContainer AssetTags;
	AssetTags.AddTag(FGameplayTag::RequestGameplayTag(FName("Ability.Attack.Ranged")));
	SetAssetTags(AssetTags);

	ActivationRequiredTags.AddTag(
		FGameplayTag::RequestGameplayTag(FName("Mode.Combat"))
	);

	ActivationRequiredTags.AddTag(
		FGameplayTag::RequestGameplayTag(FName("Turn.CanAct"))
	);

	ActivationBlockedTags.AddTag(
		FGameplayTag::RequestGameplayTag(FName("State.Stunned"))
	);

	TargetPolicy.AddRule(MakeUnique<FactionRule>(EFactionType::Enemy));
	TargetPolicy.AddRule(MakeUnique<RangeRule>(MaxRange));
	TargetPolicy.AddRule(MakeUnique<LineOfSightRule>());

	// Set a preview renderer later if you want a custom ranged preview
	PreviewRendererClass = nullptr;
}

FActionResult UGA_Attack_Ranged_LOS::BuildPreview(const FActionContext& Context) const
{
	FActionResult Result;
	BuildAttackResult(Context, Result);
	return Result;
}

FActionResult UGA_Attack_Ranged_LOS::BuildExecution(const FActionContext& Context) const
{
	FActionResult Result;
	BuildAttackResult(Context, Result);
	return Result;
}

bool UGA_Attack_Ranged_LOS::BuildAttackResult(const FActionContext& Context, FActionResult& OutResult) const
{
	OutResult = FActionResult();

	ACharacterBase* SourceCharacter = Cast<ACharacterBase>(Context.SourceActor);
	ACharacterBase* TargetCharacter = Cast<ACharacterBase>(Context.TargetActor);

	if (!SourceCharacter || !TargetCharacter)
	{
		UE_LOG(LogTemp, Warning, TEXT("[Attack_Ranged_LOS]: Invalid source or target"));
		return false;
	}

	if (!IsTargetValidForRanged(SourceCharacter, TargetCharacter))
	{
		UE_LOG(LogTemp, Warning, TEXT("[Attack_Ranged_LOS]: Target is not valid"));
		return false;
	}

	UUnitStatsComponent* SourceStats = SourceCharacter->GetUnitStats();
	UUnitStatsComponent* TargetStats = TargetCharacter->GetUnitStats();

	if (!SourceStats || !TargetStats || !TargetStats->IsAlive())
	{
		return false;
	}

	OutResult.bIsValid = true;
	OutResult.bRequiresMovement = false;
	OutResult.ActionPointsCost = BaseActionPointsCost;
	OutResult.ResolvedAttackTarget = TargetCharacter;
	OutResult.ExpectedDamage = SourceStats->GetRangedAttack() * BaseDamageMultiplier;
	OutResult.HitChance = 1.0f;
	OutResult.AffectedActors.Add(TargetCharacter);

	return true;
}

bool UGA_Attack_Ranged_LOS::IsTargetValidForRanged(
	ACharacterBase* SourceCharacter,
	ACharacterBase* TargetCharacter
) const
{
	if (!SourceCharacter || !TargetCharacter)
	{
		return false;
	}

	FActionContext ValidationContext{};
	ValidationContext.SourceActor = SourceCharacter;
	ValidationContext.TargetActor = TargetCharacter;

	if (UWorld* World = SourceCharacter->GetWorld())
	{
		if (UGridManager* Grid = World->GetSubsystem<UGridManager>())
		{
			ValidationContext.SourceGridCoord = Grid->WorldToGrid(SourceCharacter->GetActorLocation());
			ValidationContext.HoveredGridCoord = Grid->WorldToGrid(TargetCharacter->GetActorLocation());
		}
	}

	return TargetPolicy.IsValid(ValidationContext);
}

void UGA_Attack_Ranged_LOS::ActivateAbility(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo,
	const FGameplayEventData* TriggerEventData
)
{
	if (!ActorInfo || !ActorInfo->AvatarActor.IsValid())
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	ACharacterBase* SourceCharacter = Cast<ACharacterBase>(ActorInfo->AvatarActor.Get());
	if (!SourceCharacter)
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	UBattleModeComponent* BattleMode = SourceCharacter->GetBattleModeComponent();
	if (!BattleMode)
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	const FActionContext& Context = BattleMode->GetCurrentContext();
	const FActionResult ExecutionResult = BuildExecution(Context);

	if (!ExecutionResult.bIsValid)
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	CachedCharacter = SourceCharacter;
	CachedTargetCharacter = Cast<ACharacterBase>(ExecutionResult.ResolvedAttackTarget);
	CachedActionPointsCost = ExecutionResult.ActionPointsCost;

	if (!CachedTargetCharacter)
	{
		EndAbility(Handle, ActorInfo, ActivationInfo, true, true);
		return;
	}

	ApplyResolvedAttack();
	FinalizeAttackAction();
}

void UGA_Attack_Ranged_LOS::ApplyResolvedAttack()
{
	if (!CachedCharacter || !CachedTargetCharacter)
	{
		return;
	}

	UUnitStatsComponent* SourceStats = CachedCharacter->GetUnitStats();
	UUnitStatsComponent* TargetStats = CachedTargetCharacter->GetUnitStats();

	if (!SourceStats || !TargetStats || !TargetStats->IsAlive())
	{
		return;
	}

	const float Damage = SourceStats->GetRangedAttack() * BaseDamageMultiplier;
	TargetStats->SetCurrentHP(TargetStats->GetCurrentHP() - Damage);
}

void UGA_Attack_Ranged_LOS::FinalizeAttackAction()
{
	FinalizeAbilityExecution();
}

void UGA_Attack_Ranged_LOS::ApplyAbilityCompletionEffects()
{
	Super::ApplyAbilityCompletionEffects();

	if (!CachedCharacter)
	{
		return;
	}

	if (UBattleModeComponent* BattleMode = CachedCharacter->GetBattleModeComponent())
	{
		BattleMode->ConsumeActionPoints(CachedActionPointsCost);
	}
}

void UGA_Attack_Ranged_LOS::EndAbility(
	const FGameplayAbilitySpecHandle Handle,
	const FGameplayAbilityActorInfo* ActorInfo,
	const FGameplayAbilityActivationInfo ActivationInfo,
	bool bReplicateEndAbility,
	bool bWasCancelled
)
{
	CachedCharacter = nullptr;
	CachedTargetCharacter = nullptr;
	CachedActionPointsCost = 0;

	Super::EndAbility(Handle, ActorInfo, ActivationInfo, bReplicateEndAbility, bWasCancelled);
}