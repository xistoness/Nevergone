// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"
#include "Engine/DataAsset.h"
#include "AbilityDefinition.generated.h"

// Describes a single status effect that an ability can apply, along with
// how it should be displayed in the UI and how long it lasts.
USTRUCT(BlueprintType)
struct FAbilityStatusEffect
{
    GENERATED_BODY()

    // The gameplay tag that will be added to the target's ASC and BattleState
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FGameplayTag StatusTag;

    // Short label shown as floating text on the target (e.g. "STUN")
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FString DisplayLabel;

    // Optional icon shown alongside the floating text
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TObjectPtr<UTexture2D> Icon = nullptr;

    // How many full turn cycles the status lasts (0 = permanent until cleared manually)
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "0"))
    int32 DurationTurns = 1;
};

UCLASS()
class NEVERGONE_API UAbilityDefinition : public UDataAsset
{
    GENERATED_BODY()

public:
    // --- UI ---
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FText DisplayName;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TObjectPtr<UTexture2D> Icon;

    // --- Classification ---
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    FGameplayTag AbilityTag;

    // --- Range ---
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "0"))
    int32 MinRange = 1;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "0"))
    int32 MaxRange = 1;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    bool bRequiresLineOfSight = false;

    // --- Cost ---
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "0"))
    int32 ActionPointsCost = 1;
    
    // --- Effect ---
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "1.0"))
    float DamageMultiplier = 1.0;

    // --- Cooldown ---
    // Number of full turn cycles (Player → Enemy = 1 cycle) before the ability
    // can be used again. 0 means no cooldown.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, meta = (ClampMin = "0"))
    int32 CooldownTurns = 0;

    // --- Status Effects ---

    // Status effects applied to each actor hit by this ability
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<FAbilityStatusEffect> OnHitStatusEffects;

    // Status effects applied to the caster when the ability completes
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TArray<FAbilityStatusEffect> SelfStatusEffects;
};