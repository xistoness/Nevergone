// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Abilities/GameplayAbility.h"
#include "Types/BattleTypes.h"
#include "Types/BattleInputContext.h"
#include "BattleGameplayAbility.generated.h"

class UAbilityDefinition;
class UAbilityPreviewRenderer;
class UTurnManager;

UCLASS(Abstract)
class NEVERGONE_API UBattleGameplayAbility : public UGameplayAbility
{
    GENERATED_BODY()

public:
    UBattleGameplayAbility();

    virtual FActionResult BuildPreview(const FActionContext& Context) const;
    virtual FActionResult BuildExecution(const FActionContext& Context) const;
    virtual EBattleAbilitySelectionMode GetSelectionMode() const;
    virtual void FinalizeAbilityExecution();
    virtual void ApplyAbilityCompletionEffects();

    void CleanupAbilityDelegates();

    virtual TSubclassOf<UAbilityPreviewRenderer> GetPreviewClass() const;

    // The data asset that drives all configurable parameters for this ability.
    // Must be assigned in the Blueprint CDO.
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
    TObjectPtr<UAbilityDefinition> AbilityDefinition;

    bool bActivateAbilityOnGranted;

    UPROPERTY(EditDefaultsOnly, Category = "Preview")
    TSubclassOf<UAbilityPreviewRenderer> PreviewRendererClass;

protected:
    // Reads ActionPointsCost from AbilityDefinition. Returns 1 as safe fallback.
    int32 GetActionPointsCost() const;

    // Reads MaxRange from AbilityDefinition. Returns 1 as safe fallback.
    int32 GetMaxRange() const;
    
    // Reads DamageMultiplier from AbilityDefinition. Returns 1.0 as safe fallback.
    float GetDamageMultiplier() const;

    // Starts the turn-based cooldown if AbilityDefinition->CooldownTurns > 0.
    void TryStartCooldown(ACharacterBase* SourceCharacter);

    // Applies AbilityDefinition->OnHitStatusEffects to every actor in HitActors.
    // Routes through CombatEventBus so BattleState, floating text, and all
    // other listeners are notified consistently.
    void ApplyOnHitStatusEffects(
        ACharacterBase* SourceCharacter,
        const TArray<ACharacterBase*>& HitActors
    );

    // Applies AbilityDefinition->SelfStatusEffects to the caster.
    void ApplySelfStatusEffects(ACharacterBase* SourceCharacter);

private:
    void OnTurnStateChanged(EBattleTurnOwner NewOwner, EBattleTurnPhase NewPhase);
    void ClearCooldown();

    // Applies a single FAbilityStatusEffect to a target through the event bus
    void ApplyStatusEffect(
        ACharacterBase* SourceCharacter,
        ACharacterBase* TargetCharacter,
        const struct FAbilityStatusEffect& Effect
    );

    // Kept separate from any CachedCharacter in subclasses — persists after EndAbility
    UPROPERTY()
    TObjectPtr<ACharacterBase> CooldownOwner = nullptr;

    int32 RemainingCooldownTurns = 0;
    FDelegateHandle CooldownTurnHandle;
};