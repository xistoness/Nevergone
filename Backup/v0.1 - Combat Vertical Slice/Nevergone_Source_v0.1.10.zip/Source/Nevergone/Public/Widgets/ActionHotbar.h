// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ActionHotbar.generated.h"

class ACharacterBase;
class UBattleModeComponent;
class UCombatManager;
class UActionSlot;
class UHorizontalBox;
class UTextBlock;

/**
 * The ActionHotbar displays all battle abilities for the currently active unit.
 *
 * Setup:
 *   Call InitializeWithCombatManager() once when the battle HUD is created.
 *   From that point on the hotbar manages itself:
 *     - Shows and populates when a player unit becomes active (OnActiveUnitChanged).
 *     - Hides when the enemy turn begins (OnEnemyTurnBegan) or when no unit is selected.
 *     - Highlights the correct slot whenever BattleModeComponent::OnAbilitySelectionChanged fires.
 *
 * The ActionSlotClass property must be set to a Blueprint subclass of UActionSlot
 * in the WBP_ActionHotbar Blueprint defaults.
 *
 * Required widget binding in the Blueprint layout:
 *   SlotsBox  - UHorizontalBox  (receives the dynamically created ActionSlot widgets)
 */
UCLASS()
class NEVERGONE_API UActionHotbar : public UUserWidget
{
    GENERATED_BODY()

public:

    /**
     * Wires the hotbar to the active combat session.
     * Must be called once after the hotbar widget is created, before battle starts.
     * Subscribes to OnActiveUnitChanged and OnEnemyTurnBegan.
     *
     * @param InCombatManager  The CombatManager for the current battle.
     */
    UFUNCTION(BlueprintCallable, Category = "ActionHotbar")
    void InitializeWithCombatManager(UCombatManager* InCombatManager);

    /**
     * Highlights the slot at AbilityIndex and deselects all others.
     * Driven automatically by OnAbilitySelectionChanged when a unit is tracked.
     * Can also be called manually if needed.
     *
     * @param AbilityIndex  Index into GrantedBattleAbilities of the newly selected ability.
     */
    UFUNCTION(BlueprintCallable, Category = "ActionHotbar")
    void RefreshSelection(int32 AbilityIndex);

    /**
     * Removes all slots, hides the hotbar, and unbinds all delegates.
     * Call this when the battle ends or the widget is being torn down.
     */
    UFUNCTION(BlueprintCallable, Category = "ActionHotbar")
    void ClearHotbar();

protected:

    virtual void NativeDestruct() override;

    // -----------------------------------------------------------------------
    // Designer-facing configuration
    // -----------------------------------------------------------------------

    /**
     * Blueprint subclass of UActionSlot to instantiate for each ability.
     * Must be set in the WBP_ActionHotbar Blueprint defaults.
     */
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "ActionHotbar|Config")
    TSubclassOf<UActionSlot> ActionSlotClass;

    // -----------------------------------------------------------------------
    // Widget bindings — names must match exactly in the Blueprint layout
    // -----------------------------------------------------------------------

    /** Horizontal container that holds the generated ActionSlot widgets. */
    UPROPERTY(meta = (BindWidget))
    TObjectPtr<UHorizontalBox> SlotsBox;

    UPROPERTY(meta = (BindWidget))
    TObjectPtr<UTextBlock> RemainingAP;
    
    UPROPERTY(meta = (BindWidget))
    TObjectPtr<UTextBlock> APCost;
    
private:

    // ---- Internal unit management ----

    void ShowForUnit(ACharacterBase* Unit);
    void HideHotbar();
    void ClearSlots();
    void UnbindFromCurrentUnit();
    void UnbindFromCombatManager();

    // ---- CombatManager delegate handlers ----

    UFUNCTION()
    void HandleActiveUnitChanged(ACharacterBase* NewActiveUnit);

    UFUNCTION()
    void HandleEnemyTurnBegan();

    // ---- BattleModeComponent delegate handlers ----

    UFUNCTION()
    void HandleActionStarted(ACharacterBase* ActingUnit);

    UFUNCTION()
    void HandleActionFinished(ACharacterBase* ActingUnit);

    /** Called by BattleModeComponent::OnAbilitySelectionChanged when the player cycles abilities. */
    UFUNCTION()
    void HandleAbilitySelectionChanged(int32 NewIndex);

    // ---- State ----

    UPROPERTY()
    TArray<TObjectPtr<UActionSlot>> Slots;

    UPROPERTY()
    TWeakObjectPtr<ACharacterBase> TrackedUnit;

    UPROPERTY()
    TWeakObjectPtr<UBattleModeComponent> TrackedBattleMode;

    UPROPERTY()
    TWeakObjectPtr<UCombatManager> TrackedCombatManager;

    int32 CurrentSelectedIndex = INDEX_NONE;
    bool bIsLocked = false;
};