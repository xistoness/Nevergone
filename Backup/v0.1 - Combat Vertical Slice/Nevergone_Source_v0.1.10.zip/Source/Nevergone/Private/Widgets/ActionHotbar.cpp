// Copyright Xyzto Works

#include "Widgets/ActionHotbar.h"

#include "Components/HorizontalBox.h"
#include "Components/HorizontalBoxSlot.h"
#include "ActorComponents/BattleModeComponent.h"
#include "Characters/CharacterBase.h"
#include "Characters/Abilities/BattleGameplayAbility.h"
#include "Data/AbilityDefinition.h"
#include "GameMode/CombatManager.h"
#include "Types/CharacterTypes.h"
#include "Widgets/ActionSlot.h"
#include "Nevergone.h"

// ---- Public API ------------------------------------------------------------

void UActionHotbar::InitializeWithCombatManager(UCombatManager* InCombatManager)
{
    if (!InCombatManager)
    {
        UE_LOG(LogNevergone, Warning, TEXT("[ActionHotbar] InitializeWithCombatManager: received null CombatManager."));
        return;
    }

    UnbindFromCombatManager();

    TrackedCombatManager = InCombatManager;

    InCombatManager->OnActiveUnitChanged.AddDynamic(this, &UActionHotbar::HandleActiveUnitChanged);
    InCombatManager->OnEnemyTurnBegan.AddDynamic(this, &UActionHotbar::HandleEnemyTurnBegan);

    UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] InitializeWithCombatManager: bound to CombatManager."));

    HideHotbar();
}

void UActionHotbar::RefreshSelection(int32 AbilityIndex)
{
    if (bIsLocked)
    {
        UE_LOG(LogNevergone, Verbose,
            TEXT("[ActionHotbar] RefreshSelection: hotbar locked during execution — ignoring index %d."), AbilityIndex);
        return;
    }

    if (CurrentSelectedIndex == AbilityIndex)
    {
        return;
    }

    UE_LOG(LogNevergone, Log,
        TEXT("[ActionHotbar] RefreshSelection: %d → %d"), CurrentSelectedIndex, AbilityIndex);

    if (Slots.IsValidIndex(CurrentSelectedIndex))
    {
        Slots[CurrentSelectedIndex]->SetSelected(false);
    }

    if (Slots.IsValidIndex(AbilityIndex))
    {
        Slots[AbilityIndex]->SetSelected(true);
    }

    CurrentSelectedIndex = AbilityIndex;
}

void UActionHotbar::ClearHotbar()
{
    UnbindFromCombatManager();
    UnbindFromCurrentUnit();
    ClearSlots();
    bIsLocked = false;
    CurrentSelectedIndex = INDEX_NONE;

    UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] ClearHotbar: fully reset."));
}

// ---- Protected -------------------------------------------------------------

void UActionHotbar::NativeDestruct()
{
    UnbindFromCombatManager();
    UnbindFromCurrentUnit();
    Super::NativeDestruct();
}

// ---- Private — unit management ---------------------------------------------

void UActionHotbar::ShowForUnit(ACharacterBase* Unit)
{
    UnbindFromCurrentUnit();
    ClearSlots();
    CurrentSelectedIndex = INDEX_NONE;
    bIsLocked = false;

    if (!Unit)
    {
        HideHotbar();
        return;
    }

    UBattleModeComponent* BattleMode = Unit->GetBattleModeComponent();
    if (!BattleMode)
    {
        UE_LOG(LogNevergone, Warning,
            TEXT("[ActionHotbar] ShowForUnit: unit '%s' has no BattleModeComponent."), *GetNameSafe(Unit));
        HideHotbar();
        return;
    }

    if (!ActionSlotClass)
    {
        UE_LOG(LogNevergone, Error,
            TEXT("[ActionHotbar] ShowForUnit: ActionSlotClass is not set — assign it in the Blueprint defaults."));
        return;
    }

    if (!SlotsBox)
    {
        UE_LOG(LogNevergone, Error,
            TEXT("[ActionHotbar] ShowForUnit: SlotsBox binding is missing — check the widget Blueprint."));
        return;
    }

    TrackedUnit    = Unit;
    TrackedBattleMode = BattleMode;

    BattleMode->OnActionUseStarted.AddDynamic(this, &UActionHotbar::HandleActionStarted);
    BattleMode->OnActionUseFinished.AddDynamic(this, &UActionHotbar::HandleActionFinished);

    // Subscribe to ability cycling so the highlight updates automatically
    // whenever the player presses Q/E without any external call needed.
    BattleMode->OnAbilitySelectionChanged.AddDynamic(this, &UActionHotbar::HandleAbilitySelectionChanged);

    const TArray<FUnitAbilityEntry>& Abilities = BattleMode->GetGrantedBattleAbilities();

    UE_LOG(LogNevergone, Log,
        TEXT("[ActionHotbar] ShowForUnit: building %d slots for unit '%s'."),
        Abilities.Num(), *GetNameSafe(Unit));

    for (int32 Index = 0; Index < Abilities.Num(); ++Index)
    {
        const FUnitAbilityEntry& Entry = Abilities[Index];

        // Use a local name that doesn't shadow UWidget::Slot (C4458).
        UActionSlot* NewSlot = CreateWidget<UActionSlot>(this, ActionSlotClass);
        if (!NewSlot)
        {
            UE_LOG(LogNevergone, Error,
                TEXT("[ActionHotbar] ShowForUnit: failed to create ActionSlot at index %d."), Index);
            continue;
        }

        NewSlot->SetAbility(Entry.Definition);

        UHorizontalBoxSlot* BoxSlot = SlotsBox->AddChildToHorizontalBox(NewSlot);
        if (BoxSlot)
        {
            FSlateChildSize AutoSize;
            AutoSize.SizeRule = ESlateSizeRule::Automatic;
            BoxSlot->SetSize(AutoSize);
            
            // Horizontal padding between slots
            BoxSlot->SetPadding(FMargin(8.f, 0.f, 8.f, 0.f));
        }

        Slots.Add(NewSlot);
    }

    // Determine which slot should start highlighted by matching the currently
    // active ability class in the BattleModeComponent context.
    const FActionContext& CurrentCtx = BattleMode->GetCurrentContext();
    int32 InitialIndex = INDEX_NONE;

    for (int32 Index = 0; Index < Abilities.Num(); ++Index)
    {
        if (Abilities[Index].Definition &&
            Abilities[Index].Definition->AbilityClass == CurrentCtx.AbilityClass)
        {
            InitialIndex = Index;
            break;
        }
    }

    if (InitialIndex == INDEX_NONE && Slots.Num() > 0)
    {
        InitialIndex = 0;
    }

    SetVisibility(ESlateVisibility::SelfHitTestInvisible);
    RefreshSelection(InitialIndex);
}

void UActionHotbar::HideHotbar()
{
    SetVisibility(ESlateVisibility::Collapsed);
    UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] HideHotbar: hotbar is now hidden."));
}

void UActionHotbar::ClearSlots()
{
    if (SlotsBox)
    {
        SlotsBox->ClearChildren();
    }
    Slots.Empty();
}

void UActionHotbar::UnbindFromCurrentUnit()
{
    if (TrackedBattleMode.IsValid())
    {
        TrackedBattleMode->OnActionUseStarted.RemoveDynamic(this, &UActionHotbar::HandleActionStarted);
        TrackedBattleMode->OnActionUseFinished.RemoveDynamic(this, &UActionHotbar::HandleActionFinished);
        TrackedBattleMode->OnAbilitySelectionChanged.RemoveDynamic(this, &UActionHotbar::HandleAbilitySelectionChanged);

        UE_LOG(LogNevergone, Log,
            TEXT("[ActionHotbar] UnbindFromCurrentUnit: unbound from '%s'."), *GetNameSafe(TrackedUnit.Get()));
    }

    TrackedUnit.Reset();
    TrackedBattleMode.Reset();
}

void UActionHotbar::UnbindFromCombatManager()
{
    if (TrackedCombatManager.IsValid())
    {
        TrackedCombatManager->OnActiveUnitChanged.RemoveDynamic(this, &UActionHotbar::HandleActiveUnitChanged);
        TrackedCombatManager->OnEnemyTurnBegan.RemoveDynamic(this, &UActionHotbar::HandleEnemyTurnBegan);

        UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] UnbindFromCombatManager: unbound from CombatManager."));
    }

    TrackedCombatManager.Reset();
}

// ---- Private — delegate handlers -------------------------------------------

void UActionHotbar::HandleActiveUnitChanged(ACharacterBase* NewActiveUnit)
{
    if (NewActiveUnit)
    {
        UE_LOG(LogNevergone, Log,
            TEXT("[ActionHotbar] HandleActiveUnitChanged: showing hotbar for '%s'."), *GetNameSafe(NewActiveUnit));
        ShowForUnit(NewActiveUnit);
    }
    else
    {
        UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] HandleActiveUnitChanged: no unit — hiding hotbar."));
        UnbindFromCurrentUnit();
        ClearSlots();
        HideHotbar();
    }
}

void UActionHotbar::HandleEnemyTurnBegan()
{
    UE_LOG(LogNevergone, Log, TEXT("[ActionHotbar] HandleEnemyTurnBegan: hiding hotbar for enemy turn."));
    UnbindFromCurrentUnit();
    ClearSlots();
    HideHotbar();
}

void UActionHotbar::HandleActionStarted(ACharacterBase* ActingUnit)
{
    bIsLocked = true;
    UE_LOG(LogNevergone, Log,
        TEXT("[ActionHotbar] HandleActionStarted: locking hotbar for '%s'."), *GetNameSafe(ActingUnit));
}

void UActionHotbar::HandleActionFinished(ACharacterBase* ActingUnit)
{
    bIsLocked = false;

    UE_LOG(LogNevergone, Log,
        TEXT("[ActionHotbar] HandleActionFinished: unlocking hotbar for '%s'."), *GetNameSafe(ActingUnit));

    // Re-sync highlight in case the completed ability triggered an automatic
    // switch back to the default ability inside BattleModeComponent.
    if (TrackedBattleMode.IsValid())
    {
        const TArray<FUnitAbilityEntry>& Abilities = TrackedBattleMode->GetGrantedBattleAbilities();
        const FActionContext& Ctx = TrackedBattleMode->GetCurrentContext();

        for (int32 Index = 0; Index < Abilities.Num(); ++Index)
        {
            if (Abilities[Index].Definition &&
                Abilities[Index].Definition->AbilityClass == Ctx.AbilityClass)
            {
                CurrentSelectedIndex = INDEX_NONE;
                RefreshSelection(Index);
                break;
            }
        }
    }
}

void UActionHotbar::HandleAbilitySelectionChanged(int32 NewIndex)
{
    UE_LOG(LogNevergone, Log,
        TEXT("[ActionHotbar] HandleAbilitySelectionChanged: new index = %d"), NewIndex);
    RefreshSelection(NewIndex);
}