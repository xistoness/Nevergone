// Copyright Xyzto Works


#include "GameMode/CombatManager.h"

#include "ActorComponents/BattleModeComponent.h"
#include "ActorComponents/UnitStatsComponent.h"
#include "Characters/Abilities/BattleMovementAbility.h"
#include "GameInstance/MyGameInstance.h"
#include "GameMode/BattlePreparationContext.h"
#include "GameMode/Combat/BattleInputManager.h"
#include "GameMode/Combat/BattleCameraPawn.h"
#include "GameMode/Combat/BattleState.h"
#include "GameMode/Combat/CombatEventBus.h"
#include "GameMode/Combat/AI/BattleTeamAIPlanner.h"
#include "Characters/CharacterBase.h"
#include "Characters/PlayerControllers/BattlePlayerController.h"
#include "GameMode/TurnManager.h"
#include "GameMode/Combat/BattleInputContextBuilder.h"
#include "Level/GridManager.h"
#include "Types/BattleTypes.h"


void UCombatManager::Initialize()
{
	// Setup participants
}

void UCombatManager::EnterPreparation(UBattlePreparationContext& BattlePrepContext)
{
	// Lock exploration input
	// Switch camera mode
	// Initialize preview systems
}

void UCombatManager::SpawnAllies(UBattlePreparationContext& BattlePrepContext, UGridManager* Grid)
{
	for (int32 i = 0; i < BattlePrepContext.PlayerPlannedSpawns.Num(); ++i)
	{
		const FPlannedSpawn& Spawn = BattlePrepContext.PlayerPlannedSpawns[i];

		FIntPoint SpawnCoord;
		if (!Grid->FindClosestValidTileToWorld(Spawn.PlannedTransform.GetLocation(), SpawnCoord, true))
		{
			UE_LOG(
				LogTemp,
				Warning,
				TEXT("[CombatManager]: Failed to find valid ally spawn tile for index %d"),
				i
			);
			continue;
		}

		FTransform FinalSpawnTransform = Spawn.PlannedTransform;
		FinalSpawnTransform.SetLocation(Grid->GetTileCenterWorld(SpawnCoord));

		AActor* SpawnedAlly = GetWorld()->SpawnActor<AActor>(
			Spawn.ActorClass,
			FinalSpawnTransform
		);

		ACharacterBase* Character = Cast<ACharacterBase>(SpawnedAlly);
		if (!Character)
		{
			continue;
		}

		BindToCombatUnitActionEvents(Character);
		SpawnedAllies.Add(Character);

		// Inject the event bus so this unit's abilities can route through it
		if (UBattleModeComponent* BattleComp = Character->GetBattleModeComponent())
		{
			BattleComp->SetCombatEventBus(EventBus);
			BattleComp->SetTurnManager(TurnManager);
		}

		FSpawnedBattleUnit Entry;
		Entry.UnitActor = Character;
		Entry.SourceIndex = i;
		Entry.Team = EBattleUnitTeam::Ally;

		InitializeSpawnedUnitForBattle(Character, EBattleUnitTeam::Ally, Grid);

		BattlePrepContext.SpawnedUnits.Add(Entry);
		
		const FVector TileCenter = Grid->GridToWorld(SpawnCoord);

		UE_LOG(LogTemp, Warning, TEXT("TileCenter: %s"), *TileCenter.ToString());
		UE_LOG(LogTemp, Warning, TEXT("ActorLocation: %s"), *Character->GetActorLocation().ToString());

		DrawDebugSphere(GetWorld(), TileCenter, 20.f, 12, FColor::Yellow, false, 10.f);
		DrawDebugSphere(GetWorld(), Character->GetActorLocation(), 20.f, 12, FColor::Blue, false, 10.f);
		
	}
}

void UCombatManager::SpawnEnemies(UBattlePreparationContext& BattlePrepContext, UGridManager* Grid)
{
	for (int32 i = 0; i < BattlePrepContext.EnemyPlannedSpawns.Num(); ++i)
	{
		const FPlannedSpawn& Spawn = BattlePrepContext.EnemyPlannedSpawns[i];

		FIntPoint SpawnCoord;
		if (!Grid->FindClosestValidTileToWorld(Spawn.PlannedTransform.GetLocation(), SpawnCoord, true))
		{
			UE_LOG(
				LogTemp,
				Warning,
				TEXT("[CombatManager]: Failed to find valid enemy spawn tile for index %d"),
				i
			);
			continue;
		}

		FTransform FinalSpawnTransform = Spawn.PlannedTransform;
		FinalSpawnTransform.SetLocation(Grid->GetTileCenterWorld(SpawnCoord));

		AActor* SpawnedEnemy = GetWorld()->SpawnActor<AActor>(
			Spawn.ActorClass,
			FinalSpawnTransform
		);

		ACharacterBase* Character = Cast<ACharacterBase>(SpawnedEnemy);
		if (!Character)
		{
			continue;
		}

		BindToCombatUnitActionEvents(Character);
		SpawnedEnemies.Add(Character);

		// Inject the event bus so this unit's abilities can route through it
		if (UBattleModeComponent* BattleComp = Character->GetBattleModeComponent())
		{
			BattleComp->SetCombatEventBus(EventBus);
		}

		FSpawnedBattleUnit Entry;
		Entry.UnitActor = Character;
		Entry.SourceIndex = i;
		Entry.Team = EBattleUnitTeam::Enemy;
		
		InitializeSpawnedUnitForBattle(Character, EBattleUnitTeam::Enemy, Grid);

		BattlePrepContext.SpawnedUnits.Add(Entry);
		
		const FVector TileCenter = Grid->GridToWorld(SpawnCoord);

		UE_LOG(LogTemp, Warning, TEXT("TileCenter: %s"), *TileCenter.ToString());
		UE_LOG(LogTemp, Warning, TEXT("ActorLocation: %s"), *Character->GetActorLocation().ToString());

		DrawDebugSphere(GetWorld(), TileCenter, 20.f, 12, FColor::Yellow, false, 10.f);
		DrawDebugSphere(GetWorld(), Character->GetActorLocation(), 20.f, 12, FColor::Blue, false, 10.f);
	}
}

void UCombatManager::StartCombat(UBattlePreparationContext& BattlePrepContext)
{	
	UE_LOG(LogTemp, Warning, TEXT("=== StartCombat ==="));
	LogActivePlayerController(GetWorld(), TEXT("StartCombat BEGIN"));
	
	UGridManager* Grid = GetWorld()->GetSubsystem<UGridManager>();
	if (!Grid)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager]: Grid is invalid..."));
		return;
	}
	
	// EventBus must exist before spawning so units receive the reference
	// during SetCombatEventBus() calls inside SpawnAllies/SpawnEnemies.
	// BattleState is initialized after spawning because Initialize() reads
	// BattlePrepContext.SpawnedUnits, which is populated during the spawn loop.
	EventBus = NewObject<UCombatEventBus>(this);
	EventBus->OnUnitDied.AddUObject(this, &UCombatManager::HandleUnitDeath);

	SpawnAllies(BattlePrepContext, Grid);
	SpawnEnemies(BattlePrepContext, Grid);

	TArray<AActor*> AllCombatants;
	AllCombatants.Append(SpawnedAllies);
	AllCombatants.Append(SpawnedEnemies);

	// Create turn manager
	TurnManager = NewObject<UTurnManager>(this);
	TurnManager->Initialize(AllCombatants);
	
	// Create battle team AI planner
	BattleTeamAIPlanner = NewObject<UBattleTeamAIPlanner>(this);
	BattleTeamAIPlanner->Initialize(AllCombatants);
	BattleTeamAIPlanner->OnAIActionFinished.AddUObject(this, &UCombatManager::HandleAIActionFinished);

	// Create input manager
	BattleInputManager = NewObject<UBattleInputManager>(this);
	BattleInputManager->Initialize(TurnManager, BattleCameraPawn, this);
	
	// Create input context builder
	InputContextBuilder = NewObject<UBattleInputContextBuilder>(this);
	InputContextBuilder->SetTurnManager(TurnManager);
	UpdateInputContext();

	// BattleState is initialized here
	BattleState = NewObject<UBattleState>();
	BattleState->Initialize(BattlePrepContext);

	// Wire BattleState
	EventBus->Initialize(BattleState);
	BattleTeamAIPlanner->SetBattleState(BattleState);
	
	for (ACharacterBase* Unit : SpawnedAllies)
	{
		if (UBattleModeComponent* BattleComp = Unit ? Unit->GetBattleModeComponent() : nullptr)
		{
			BattleComp->SetBattleState(BattleState);
		}
	}
	for (ACharacterBase* Unit : SpawnedEnemies)
	{
		if (UBattleModeComponent* BattleComp = Unit ? Unit->GetBattleModeComponent() : nullptr)
		{
			BattleComp->SetBattleState(BattleState);
		}
	}

	// Bind turn events
	TurnManager->OnTurnStateChanged.AddUObject(
	this,
	&UCombatManager::HandleTurnStateChanged
	);
	
	// Tells the Battle Player Controller to start battle
	if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
	{
		if (ABattlePlayerController* BattlePC =
			Cast<ABattlePlayerController>(PC))
		{
			BattlePC->EnterBattleMode(this);
			
		}
	}
	
	//  Tells the Turn Manager to start combat and trigger first turn
	TurnManager->StartCombat();
}

void UCombatManager::InitializeSpawnedUnitForBattle(ACharacterBase* Character, EBattleUnitTeam Team, UGridManager* Grid)
{
	if (!Character || !Grid)
	{
		return;
	}

	Grid->RegisterActorToGrid(Character);

	// Assign team identity — this is persistent data, not battle session data
	if (UUnitStatsComponent* UnitStats = Character->GetUnitStats())
	{
		switch (Team)
		{
		case EBattleUnitTeam::Ally:
			UnitStats->SetAllyTeam(0);
			UnitStats->SetEnemyTeam(1);
			break;
		case EBattleUnitTeam::Enemy:
			UnitStats->SetAllyTeam(1);
			UnitStats->SetEnemyTeam(0);
			break;
		default:
			break;
		}
	}
}

void UCombatManager::HandleTurnStateChanged(
	EBattleTurnOwner NewOwner,
	EBattleTurnPhase NewPhase)
{
	if (NewOwner == EBattleTurnOwner::Player &&
		NewPhase == EBattleTurnPhase::AwaitingOrders)
	{
		OnPlayerTurnStarted();
	}
	else if (NewOwner == EBattleTurnOwner::Enemy &&
		NewPhase == EBattleTurnPhase::ExecutingActions)
	{
		OnEnemyTurnStarted();
	}
}

void UCombatManager::HandleUnitDeath(ACharacterBase* DeadUnit)
{
	if (!DeadUnit)
	{
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[CombatManager]: Unit died: %s"), *DeadUnit->GetName());

	// Optional: remove from grid occupancy immediately
	if (UGridManager* Grid = GetWorld()->GetSubsystem<UGridManager>())
	{
		Grid->RemoveActorFromGrid(DeadUnit);
	}

	if (IsTeamDefeated(EBattleUnitTeam::Enemy))
	{
		EndCombatWithWinner(EBattleUnitTeam::Ally);
		return;
	}

	if (IsTeamDefeated(EBattleUnitTeam::Ally))
	{
		EndCombatWithWinner(EBattleUnitTeam::Enemy);
		return;
	}
}

bool UCombatManager::IsTeamDefeated(EBattleUnitTeam Team) const
{
	const TArray<ACharacterBase*>* TeamUnits = nullptr;

	switch (Team)
	{
	case EBattleUnitTeam::Ally:  TeamUnits = &SpawnedAllies;  break;
	case EBattleUnitTeam::Enemy: TeamUnits = &SpawnedEnemies; break;
	default: return false;
	}

	for (ACharacterBase* Unit : *TeamUnits)
	{
		if (!Unit) { continue; }

		// Read alive state from BattleUnitState — the authority during combat
		if (BattleState)
		{
			const FBattleUnitState* State = BattleState->FindUnitState(Unit);
			if (State && State->IsAlive()) { return false; }
		}
	}

	return true;
}

void UCombatManager::UpdateInputContext()
{
	if (!InputContextBuilder || !BattleInputManager || bCombatEnding)
	{
		return;
	}

	const FBattleInputContext Context = InputContextBuilder->BuildContext();

	BattleInputManager->SetInputContext(Context);
}

void UCombatManager::RegisterBattleCamera(ABattleCameraPawn* InCameraPawn)
{
	BattleCameraPawn = InCameraPawn;

	if (BattleInputManager)
	{
		// Late binding safety
		BattleInputManager->Initialize(TurnManager, BattleCameraPawn, this);
	}
}

void UCombatManager::OnPlayerTurnStarted()
{
	UE_LOG(LogTemp, Warning, TEXT("[CombatManager]: Player turn started"));
	if (!InputContextBuilder || bCombatEnding) return;
	
	ClearCurrentSelectedUnit();
	
	BattleState->ResetTurnStateForTeam(EBattleUnitTeam::Ally);
	
	InputContextBuilder->SetUnitInputEnabled(true);
	InputContextBuilder->SetCameraInputEnabled(true);
	InputContextBuilder->SetHardLock(false);
	UpdateInputContext();
	
	SelectedUnit = INDEX_NONE;
	SelectFirstAvailableUnit();
}

void UCombatManager::OnEnemyTurnStarted()
{
	UE_LOG(LogTemp, Warning, TEXT("[CombatManager]: Enemy turn started"));
	if (!InputContextBuilder || bCombatEnding) return;
	
	ClearCurrentSelectedUnit();
	OnEnemyTurnBegan.Broadcast();
	
	BattleState->ResetTurnStateForTeam(EBattleUnitTeam::Enemy);

	InputContextBuilder->SetCameraInputEnabled(false);
	InputContextBuilder->SetHardLock(true);
	UpdateInputContext();
	
	BattleTeamAIPlanner->StartTeamTurn();
}

void UCombatManager::SelectFirstAvailableUnit()
{
	if (bCombatEnding) return;
	for (int32 i = 0; i < SpawnedAllies.Num(); ++i)
	{
		ACharacterBase* Unit = Cast<ACharacterBase>(SpawnedAllies[i]);
		if (!Unit)
		{
			continue;
		}

		if (BattleState && BattleState->CanUnitAct(Unit))
		{
			SelectedUnit = i;
			HandleActiveUnitChanged(Unit);
			return;
		}
	}
	
	// No valid unit found
	EndPlayerTurn();	
}

void UCombatManager::SelectNextControllableUnit()
{
	if (SpawnedAllies.Num() == 0 || !BattleState || bCombatEnding)
	{
		return;
	}
	
	if (SelectedUnit == INDEX_NONE)
	{
		SelectFirstAvailableUnit();
		return;
	}

	const int32 StartIndex = SelectedUnit;
	int32 Index = SelectedUnit;

	do
	{
		Index = (Index + 1) % SpawnedAllies.Num();

		ACharacterBase* Unit = Cast<ACharacterBase>(SpawnedAllies[Index]);
		if (Unit && BattleState->CanUnitAct(Unit))
		{
			SelectedUnit = Index;
			HandleActiveUnitChanged(Unit);
			return;
		}

	} while (Index != StartIndex);
	
	EndPlayerTurn();
}

void UCombatManager::SelectPreviousControllableUnit()
{
	if (bCombatEnding) return;
	
	if (SpawnedAllies.Num() == 0 || !BattleState)
	{
		return;
	}
	
	if (SelectedUnit == INDEX_NONE)
	{
		SelectFirstAvailableUnit();
		return;
	}

	const int32 Count = SpawnedAllies.Num();
	const int32 StartIndex = SelectedUnit;

	int32 Index = SelectedUnit;

	do
	{
		Index = (Index - 1 + Count) % Count;

		ACharacterBase* Unit = Cast<ACharacterBase>(SpawnedAllies[Index]);
		if (Unit && BattleState->CanUnitAct(Unit))
		{
			SelectedUnit = Index;
			HandleActiveUnitChanged(Unit);
			return;
		}

	} while (Index != StartIndex);

	EndPlayerTurn();
}


void UCombatManager::HandleActiveUnitChanged(ACharacterBase* NewActiveUnit)
{
	if (!NewActiveUnit || !BattleCameraPawn || !TurnManager || bCombatEnding)
	{
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Tries to handle active unit changed..."));

	if (InputContextBuilder)
	{
		InputContextBuilder->SetInteractionMode(EBattleInteractionMode::Targeting);
		UpdateInputContext();
	}
	else
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] InputContextBuilder invalid"));
	}

	if (CurrentSelectedUnit)
	{
		if (UBattleModeComponent* OldBattleComp = CurrentSelectedUnit->FindComponentByClass<UBattleModeComponent>())
		{
			OldBattleComp->OnActionPointsDepleted.RemoveDynamic(
				this,
				&UCombatManager::HandleUnitOutOfAP
			);
		}
	}

	CurrentSelectedUnit = NewActiveUnit;
	OnActiveUnitChanged.Broadcast(CurrentSelectedUnit);

	if (UBattleModeComponent* NewBattleComp = CurrentSelectedUnit->FindComponentByClass<UBattleModeComponent>())
	{
		NewBattleComp->OnActionPointsDepleted.AddUniqueDynamic(
			this,
			&UCombatManager::HandleUnitOutOfAP
		);
	}

	if (BattleInputManager)
	{
		BattleInputManager->OnActiveUnitChanged(CurrentSelectedUnit);
	}
}

void UCombatManager::HandleUnitOutOfAP(ACharacterBase* Unit)
{
	if (bCombatEnding || !TurnManager || !BattleState)
	{
		return;
	}

	if (TurnManager->GetCurrentTurnOwner() != EBattleTurnOwner::Player)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Ignoring OutOfAP: not player's turn."));
		return;
	}

	if (Unit != CurrentSelectedUnit)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Ignoring OutOfAP: unit is not current selected unit."));
		return;
	}

	// If a post-action delay is in progress, suppress the unit switch here.
	// The delay callback will call SelectNextControllableUnit once it fires,
	// ensuring the camera only moves after the full delay has elapsed.
	if (GetWorld()->GetTimerManager().IsTimerActive(PostActionDelayHandle) || bWaitingForPathFinish)
	{
		UE_LOG(LogTemp, Log, TEXT("[CombatManager] OutOfAP suppressed — waiting for post-action delay or path finish."));
		return;
	}

	SelectNextControllableUnit();
}

void UCombatManager::EndPlayerTurn()
{
	if (bCombatEnding || !TurnManager)
	{
		return;
	}

	if (TurnManager->GetCurrentTurnOwner() != EBattleTurnOwner::Player)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Ignoring EndPlayerTurn: current turn is not Player."));
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("[CombatManager] No units left. Ending player turn."));

	ClearCurrentSelectedUnit();

	if (BattleInputManager)
	{
		BattleInputManager->OnActiveUnitChanged(nullptr);
	}

	TurnManager->EndCurrentTurn();
}

void UCombatManager::EndEnemyTurn()
{
	if (bCombatEnding || !TurnManager)
	{
		return;
	}

	if (TurnManager->GetCurrentTurnOwner() != EBattleTurnOwner::Enemy)
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Ignoring EndEnemyTurn: current turn is not Enemy."));
		return;
	}

	UE_LOG(LogTemp, Log, TEXT("[CombatManager] No AI actions left. Finishing enemy turn."));

	ClearCurrentSelectedUnit();
	
	if (BattleInputManager)
	{
		BattleInputManager->OnActiveUnitChanged(nullptr);
	}
	
	if (BattleCameraPawn)
	{
		BattleCameraPawn->ClearLockOnActor();
	}
	
	if (InputContextBuilder)
	{
		InputContextBuilder->SetUnitInputEnabled(false);
		InputContextBuilder->SetCameraInputEnabled(true);
		InputContextBuilder->SetHardLock(false);		
	}
	
	TurnManager->EndCurrentTurn();
}

void UCombatManager::RequestEndEnemyTurn()
{
	EndEnemyTurn();
}

void UCombatManager::CancelPreparation()
{
	Cleanup();
}

void UCombatManager::ClearCurrentSelectedUnit()
{
	if (!CurrentSelectedUnit)
	{
		SelectedUnit = INDEX_NONE;
		return;
	}

	if (UBattleModeComponent* BattleComp = CurrentSelectedUnit->FindComponentByClass<UBattleModeComponent>())
	{
		BattleComp->OnActionPointsDepleted.RemoveAll(this);
	}

	CurrentSelectedUnit = nullptr;
	OnActiveUnitChanged.Broadcast(nullptr);
	SelectedUnit = INDEX_NONE;
}

void UCombatManager::EndCombatWithWinner(EBattleUnitTeam WinningTeam)
{
	if (bCombatEnding) { return; }
	bCombatEnding = true;

	if (InputContextBuilder)
	{
		InputContextBuilder->SetCameraInputEnabled(false);
		InputContextBuilder->SetUnitInputEnabled(false);
	}

	// Persist HP and any other battle outcomes back to UnitStatsComponents
	// before actors are destroyed in Cleanup()
	if (BattleState)
	{
		BattleState->GenerateResult();
	}

	OnCombatFinished.Broadcast(WinningTeam);
}

int32 UCombatManager::GetAliveAllies() const
{
	int32 Count = 0;
	for (ACharacterBase* Ally : SpawnedAllies)
	{
		if (!IsValid(Ally) || !BattleState) { continue; }
		const FBattleUnitState* State = BattleState->FindUnitState(Ally);
		if (State && State->IsAlive()) { ++Count; }
	}
	return Count;
}

int32 UCombatManager::GetAliveEnemies() const
{
	int32 Count = 0;
	for (ACharacterBase* Enemy : SpawnedEnemies)
	{
		if (!IsValid(Enemy) || !BattleState) { continue; }
		const FBattleUnitState* State = BattleState->FindUnitState(Enemy);
		if (State && State->IsAlive()) { ++Count; }
	}
	return Count;
}

void UCombatManager::Cleanup()
{
	bCombatEnding = true;
	
	// Cancel any pending post-action delay to avoid dangling callbacks
	if (GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(PostActionDelayHandle);
		GetWorld()->GetTimerManager().ClearTimer(AICameraWaitHandle);
		bWaitingForPathFinish = false;

	}

	if (CurrentSelectedUnit)
	{
		if (UBattleModeComponent* BattleComp = CurrentSelectedUnit->FindComponentByClass<UBattleModeComponent>())
		{
			BattleComp->OnActionPointsDepleted.RemoveAll(this);
		}

		CurrentSelectedUnit = nullptr;
	}

	if (TurnManager)
	{
		TurnManager->OnTurnStateChanged.RemoveAll(this);
	}

	if (UGridManager* Grid = GetWorld()->GetSubsystem<UGridManager>())
	{
		for (ACharacterBase* Ally : SpawnedAllies)
		{
			if (IsValid(Ally))
			{
				UnbindFromCombatUnitActionEvents(Ally);
				Grid->RemoveActorFromGrid(Ally);
				UE_LOG(LogTemp, Error, TEXT("[CombatManager]: Destroying ally -> %s"), *GetNameSafe(Ally));
				Ally->Destroy();
			}
		}

		for (ACharacterBase* Enemy : SpawnedEnemies)
		{
			if (IsValid(Enemy))
			{
				UnbindFromCombatUnitActionEvents(Enemy);
				Grid->RemoveActorFromGrid(Enemy);
				UE_LOG(LogTemp, Error, TEXT("[CombatManager]: Destroying enemy -> %s"), *GetNameSafe(Enemy));
				Enemy->Destroy();
			}
		}
	}
	else
	{
		for (ACharacterBase* Ally : SpawnedAllies)
		{
			if (IsValid(Ally))
			{
				Ally->Destroy();
			}
		}

		for (ACharacterBase* Enemy : SpawnedEnemies)
		{
			if (IsValid(Enemy))
			{
				Enemy->Destroy();
			}
		}
	}

	SpawnedAllies.Empty();
	SpawnedEnemies.Empty();

	if (IsValid(BattleCameraPawn))
	{
		BattleCameraPawn->Destroy();
		BattleCameraPawn = nullptr;
	}

	SelectedUnit = INDEX_NONE;
	InputContextBuilder = nullptr;
	BattleInputManager = nullptr;
	TurnManager = nullptr;
	BattleState = nullptr;
	EventBus = nullptr;
}

void UCombatManager::BindToCombatUnitActionEvents(ACharacterBase* Unit)
{
	if (!Unit)
	{
		return;
	}

	if (UBattleModeComponent* BattleComp = Unit->FindComponentByClass<UBattleModeComponent>())
	{
		BattleComp->OnActionUseStarted.RemoveDynamic(this, &UCombatManager::HandleUnitActionStarted);
		BattleComp->OnActionUseFinished.RemoveDynamic(this, &UCombatManager::HandleUnitActionFinished);

		BattleComp->OnActionUseStarted.AddDynamic(this, &UCombatManager::HandleUnitActionStarted);
		BattleComp->OnActionUseFinished.AddDynamic(this, &UCombatManager::HandleUnitActionFinished);
	}
}

void UCombatManager::UnbindFromCombatUnitActionEvents(ACharacterBase* Unit)
{
	if (!Unit)
	{
		return;
	}

	if (UBattleModeComponent* BattleComp = Unit->FindComponentByClass<UBattleModeComponent>())
	{
		BattleComp->OnActionUseStarted.RemoveDynamic(this, &UCombatManager::HandleUnitActionStarted);
		BattleComp->OnActionUseFinished.RemoveDynamic(this, &UCombatManager::HandleUnitActionFinished);
	}
}

void UCombatManager::HandleUnitActionStarted(ACharacterBase* ActingUnit)
{
	if (bCombatEnding || !InputContextBuilder || !TurnManager)
	{
		return;
	}

	UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Action started -> updating input state"));

	const EBattleTurnOwner TurnOwner = TurnManager->GetCurrentTurnOwner();

	if (TurnOwner == EBattleTurnOwner::Player)
	{
		InputContextBuilder->SetUnitInputEnabled(false);
		InputContextBuilder->SetCameraInputEnabled(true);
		InputContextBuilder->SetHardLock(false);
	}
	else
	{
		InputContextBuilder->SetUnitInputEnabled(false);
		InputContextBuilder->SetCameraInputEnabled(false);
		InputContextBuilder->SetHardLock(true);
		BattleCameraPawn->LockOnActor(ActingUnit);

		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Action started -> focusing camera on acting enemy"));
		FocusCameraOnActingEnemy(ActingUnit);
	}

	UpdateInputContext();
}

void UCombatManager::HandleUnitActionFinished(ACharacterBase* ActingUnit)
{
    if (bCombatEnding || !InputContextBuilder || !TurnManager)
    {
        return;
    }

    InputContextBuilder->SetUnitInputEnabled(false);
    InputContextBuilder->SetCameraInputEnabled(false);
    InputContextBuilder->SetHardLock(true);
    UpdateInputContext();

    UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Action finished -> updating input state"));

    // Check if this was a movement ability. If so, wait for the physical path to finish
    // before restoring input. OnActionUseFinished fires before the character reaches
    // the destination, so using a timer here would restore input too early (or not at all
    // with delay 0). Instead we bind once to OnPathMoveFinished on the acting unit.
    const bool bWasMovement = [&]() -> bool
    {
        if (const UBattleModeComponent* BattleComp = ActingUnit ? ActingUnit->GetBattleModeComponent() : nullptr)
        {
            const TSubclassOf<UGameplayAbility> UsedClass = BattleComp->GetCurrentContext().AbilityClass;
            return UsedClass && UsedClass->IsChildOf(UBattleMovementAbility::StaticClass());
        }
        return false;
    }();

    // For movement, use a minimal delay (one frame) so the timer fires after
    // the current Broadcast call stack unwinds. OnPathMoveFinished triggers
    // FinalizeAbilityExecution which synchronously calls us — binding to
    // OnPathMoveFinished here would arrive after the event already fired.
    const float Delay = bWasMovement ? 0.05f : 1.0f;
    if (bWasMovement) { bWaitingForPathFinish = true; }

    GetWorld()->GetTimerManager().SetTimer(
        PostActionDelayHandle,
        [this, ActingUnit]()
        {
            bWaitingForPathFinish = false;
            RestoreInputAfterAction(ActingUnit);
        }, Delay, false);
}

void UCombatManager::RestoreInputAfterAction(ACharacterBase* ActingUnit)
{
    if (bCombatEnding || !InputContextBuilder || !TurnManager)
    {
        return;
    }

    UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Restoring input after action"));

    if (TurnManager->GetCurrentTurnOwner() == EBattleTurnOwner::Player)
    {
        InputContextBuilder->SetUnitInputEnabled(true);
        InputContextBuilder->SetCameraInputEnabled(true);
        InputContextBuilder->SetHardLock(false);

        if (ActingUnit && BattleState && !BattleState->CanUnitAct(ActingUnit))
        {
            SelectNextControllableUnit();
        }
        else if (ActingUnit && BattleState && BattleState->CanUnitAct(ActingUnit))
        {
            InputContextBuilder->SetInteractionMode(EBattleInteractionMode::Targeting);
        }
    }
    else
    {
        InputContextBuilder->SetUnitInputEnabled(false);
        InputContextBuilder->SetCameraInputEnabled(false);
        InputContextBuilder->SetHardLock(true);
        BattleCameraPawn->ClearLockOnActor();
    }

    UpdateInputContext();
}

void UCombatManager::HandleAIActionFinished()
{
    if (bCombatEnding || !BattleTeamAIPlanner) { return; }

    // If the camera is still moving toward the acting unit, poll until it arrives.
    // This prevents the planner from starting the next action while the camera
    // is still catching up, which caused the 1s timer to fire mid-movement.
    if (BattleCameraPawn && BattleCameraPawn->HasLockedActor() && !BattleCameraPawn->IsNearLockedActor())
    {
        UE_LOG(LogTemp, Log, TEXT("[CombatManager] AI action finished — waiting for camera to reach actor"));
        GetWorld()->GetTimerManager().SetTimer(
            AICameraWaitHandle,
            this,
            &UCombatManager::PollCameraReachedActor,
            0.05f,
            true
        );
    }
    else
    {
        UE_LOG(LogTemp, Log, TEXT("[CombatManager] AI action finished — camera already arrived, continuing"));
        BattleTeamAIPlanner->ContinueAfterActionDelay();
    }
}

void UCombatManager::PollCameraReachedActor()
{
    if (!BattleCameraPawn || !BattleTeamAIPlanner)
    {
        GetWorld()->GetTimerManager().ClearTimer(AICameraWaitHandle);
        return;
    }

    if (BattleCameraPawn->IsNearLockedActor())
    {
        UE_LOG(LogTemp, Log, TEXT("[CombatManager] Camera reached actor — continuing AI sequence"));
        GetWorld()->GetTimerManager().ClearTimer(AICameraWaitHandle);
        BattleTeamAIPlanner->ContinueAfterActionDelay();
    }
}

void UCombatManager::FocusCameraOnActingEnemy(ACharacterBase* ActingUnit)
{
	if (!ActingUnit || !BattleInputManager)
	{
		return;
	}
	
	BattleCameraPawn = BattleInputManager->GetBattleCameraPawn();
	if (!IsValid(BattleCameraPawn))
	{
		UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Battle camera pawn is invalid!"));
		return;
	}
	
	UE_LOG(LogTemp, Warning, TEXT("[CombatManager] Locking camera to enemy unit"));

	const FVector FocusLocation = ActingUnit->GetActorLocation();
	BattleCameraPawn->FocusOnLocationSmooth(FocusLocation);
}

void UCombatManager::LogActivePlayerController(UWorld* World, const FString& Context)
{
	if (!World)
	{
		UE_LOG(LogTemp, Error, TEXT("[%s] World is null"), *Context);
		return;
	}

	APlayerController* PC = World->GetFirstPlayerController();

	if (!PC)
	{
		UE_LOG(LogTemp, Error, TEXT("[%s] No PlayerController found"), *Context);
		return;
	}

	APawn* Pawn = PC->GetPawn();

	UE_LOG(LogTemp, Log,
	TEXT("[%s] PC=%s | Pawn=%s | Local=%s | Paused=%s"),
	*Context,
	*PC->GetName(),
	Pawn ? *Pawn->GetName() : TEXT("None"),
	PC->IsLocalController() ? TEXT("Yes") : TEXT("No"),
	PC->IsPaused() ? TEXT("Yes") : TEXT("No")
	);
}