// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "InputActionValue.h"
#include "NevergonePlayerController.h"
#include "ExplorationPlayerController.generated.h"

class UDialogueWidget;
class UDialogueSubsystem;
class UInputAction;

UENUM(BlueprintType)
enum class EExplorationInputMode : uint8
{
    Gameplay,
    Dialogue
};

UCLASS()
class NEVERGONE_API AExplorationPlayerController : public ANevergonePlayerController
{
    GENERATED_BODY()

public:
    virtual void SetupInputComponent() override;

    void ApplyExplorationInputMode();
    void ApplyDialogueInputMode();

    void EnterDialogueInputMode();
    void ExitDialogueInputMode();

    void OnLook(const FInputActionValue& Value);

    UPROPERTY(EditDefaultsOnly, Category = "Input")
    UInputAction* LookInput;

    UPROPERTY(EditDefaultsOnly, Category = "Input")
    UInputAction* InteractionInput;

    UPROPERTY(EditDefaultsOnly, Category = "Input|Dialogue")
    UInputAction* DialogueConfirmInput;

    UPROPERTY(EditDefaultsOnly, Category = "Input|Dialogue")
    UInputAction* DialogueCancelInput;

    UPROPERTY(EditDefaultsOnly, Category = "Input|Dialogue")
    UInputAction* DialogueNextChoiceInput;

    UPROPERTY(EditDefaultsOnly, Category = "Input|Dialogue")
    UInputAction* DialoguePreviousChoiceInput;

    void HandleInteract();
    void HandleDialogueConfirm();
    void HandleDialogueCancel();
    void HandleDialogueNextChoice();
    void HandleDialoguePreviousChoice();
    
    void CreateDialogueWidget();

protected:

    UPROPERTY(EditAnywhere, Category = "Input|Look")
    float MouseSensitivity = 0.75f;

    UPROPERTY(EditDefaultsOnly, Category = "UI")
    TSubclassOf<UDialogueWidget> DialogueWidgetClass;

    UPROPERTY()
    UDialogueWidget* DialogueWidget = nullptr;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Input")
    EExplorationInputMode CurrentInputMode = EExplorationInputMode::Gameplay;

    virtual void BeginPlay() override;
    virtual void OnPossess(APawn* InPawn) override;
    virtual void OnUnPossess() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:

    void BindDialogueSubsystem();
    void HandleDialogueStarted();
    void HandleDialogueEnded();

    UPROPERTY()
    UDialogueSubsystem* DialogueSubsystem = nullptr;
};