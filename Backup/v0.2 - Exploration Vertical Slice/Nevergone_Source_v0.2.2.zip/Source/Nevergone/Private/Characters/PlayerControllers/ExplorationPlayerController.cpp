// Copyright Xyzto Works

#include "Characters/PlayerControllers/ExplorationPlayerController.h"

#include "EnhancedInputComponent.h"
#include "ActorComponents/ExplorationModeComponent.h"
#include "Characters/CharacterBase.h"
#include "GameInstance/GameContextManager.h"
#include "Interfaces/ExplorationInputReceiver.h"
#include "Widgets/DialogueWidget.h"
#include "Widgets/QuestLogWidget.h"
#include "World/DialogueSubsystem.h"

void AExplorationPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    if (UEnhancedInputComponent* EIC = Cast<UEnhancedInputComponent>(InputComponent))
    {
        if (LookInput)
        {
            EIC->BindAction(LookInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::OnLook);
        }

        if (InteractionInput)
        {
            EIC->BindAction(InteractionInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::HandleInteract);
        }

        if (DialogueConfirmInput)
        {
            EIC->BindAction(DialogueConfirmInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::HandleDialogueConfirm);
        }

        if (DialogueCancelInput)
        {
            EIC->BindAction(DialogueCancelInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::HandleDialogueCancel);
        }

        if (DialogueNextChoiceInput)
        {
            EIC->BindAction(DialogueNextChoiceInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::HandleDialogueNextChoice);
        }

        if (DialoguePreviousChoiceInput)
        {
            EIC->BindAction(DialoguePreviousChoiceInput, ETriggerEvent::Triggered, this, &AExplorationPlayerController::HandleDialoguePreviousChoice);
        }
    }
}

void AExplorationPlayerController::ApplyExplorationInputMode()
{
    CurrentInputMode = EExplorationInputMode::Gameplay;

    SetIgnoreMoveInput(false);
    SetIgnoreLookInput(false);

    bShowMouseCursor = false;
    bEnableClickEvents = false;
    bEnableMouseOverEvents = false;

    FInputModeGameOnly InputMode;
    SetInputMode(InputMode);

    UE_LOG(LogTemp, Log, TEXT("[ExplorationPlayerController] Input mode -> Gameplay"));
}

void AExplorationPlayerController::ApplyDialogueInputMode()
{
    CurrentInputMode = EExplorationInputMode::Dialogue;

    // Keep movement/look blocked while dialogue is open
    SetIgnoreMoveInput(true);
    SetIgnoreLookInput(true);

    bShowMouseCursor = true;
    bEnableClickEvents = true;
    bEnableMouseOverEvents = true;

    // Important: do NOT use UIOnly here. Your previous log already showed
    // focus problems with a non-focusable widget.
    FInputModeGameAndUI InputMode;
    InputMode.SetHideCursorDuringCapture(false);
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
    SetInputMode(InputMode);

    UE_LOG(LogTemp, Log, TEXT("[ExplorationPlayerController] Input mode -> Dialogue"));
}

void AExplorationPlayerController::EnterDialogueInputMode()
{
    ApplyDialogueInputMode();
}

void AExplorationPlayerController::ExitDialogueInputMode()
{
    ApplyExplorationInputMode();
}

void AExplorationPlayerController::OnLook(const FInputActionValue& Value)
{
    if (CurrentInputMode != EExplorationInputMode::Gameplay)
    {
        return;
    }

    const FVector2D LookAxis = Value.Get<FVector2D>();

    AddYawInput(LookAxis.X * MouseSensitivity);
    AddPitchInput(LookAxis.Y * MouseSensitivity);
}

void AExplorationPlayerController::HandleInteract()
{
    if (CurrentInputMode == EExplorationInputMode::Dialogue)
    {
        HandleDialogueConfirm();
        return;
    }

    APawn* MyPawn = GetPawn();
    if (!MyPawn) { return; }

    if (IExplorationInputReceiver* Actions = MyPawn->FindComponentByClass<UExplorationModeComponent>())
    {
        Actions->Input_Interact();
    }
}

void AExplorationPlayerController::HandleQuestLog()
{
}

void AExplorationPlayerController::HandleDialogueConfirm()
{
    if (CurrentInputMode != EExplorationInputMode::Dialogue)
    {
        return;
    }

    if (DialogueWidget)
    {
        DialogueWidget->ConfirmCurrentChoice();
    }
}

void AExplorationPlayerController::HandleDialogueCancel()
{
    if (CurrentInputMode != EExplorationInputMode::Dialogue)
    {
        return;
    }

    if (DialogueWidget)
    {
        DialogueWidget->CancelDialogue();
    }
}

void AExplorationPlayerController::HandleDialogueNextChoice()
{
    if (CurrentInputMode != EExplorationInputMode::Dialogue)
    {
        return;
    }

    if (DialogueWidget)
    {
        DialogueWidget->SelectNextChoice();
    }
}

void AExplorationPlayerController::HandleDialoguePreviousChoice()
{
    if (CurrentInputMode != EExplorationInputMode::Dialogue)
    {
        return;
    }

    if (DialogueWidget)
    {
        DialogueWidget->SelectPreviousChoice();
    }
}

void AExplorationPlayerController::CreateDialogueWidget()
{
    if (!IsValid(DialogueWidgetClass))
    {
        UE_LOG(LogTemp, Warning, TEXT("[ExplorationPlayerController] DialogueWidgetClass is null."));
        return;
    }

    if (DialogueWidget)
    {
        return;
    }

    DialogueWidget = CreateWidget<UDialogueWidget>(this, DialogueWidgetClass);
    if (!DialogueWidget)
    {
        UE_LOG(LogTemp, Error, TEXT("[ExplorationPlayerController] CreateDialogueWidget: CreateWidget failed"));
        return;
    }

    DialogueWidget->AddToViewport(100);
    DialogueWidget->SetVisibility(ESlateVisibility::Hidden);

    UE_LOG(LogTemp, Log, TEXT("[ExplorationPlayerController] DialogueWidget created"));
}

void AExplorationPlayerController::CreateQuestLogWidget()
{
    if (!IsValid(QuestLogWidgetClass))
    {
        UE_LOG(LogTemp, Warning, TEXT("[ExplorationPlayerController] QuestLogWidgetClass is null."));
        return;
    }

    if (QuestLogWidget)
    {
        return;
    }

    QuestLogWidget = CreateWidget<UQuestLogWidget>(this, QuestLogWidgetClass);
    if (!QuestLogWidget)
    {
        UE_LOG(LogTemp, Error, TEXT("[ExplorationPlayerController] CreateQuestLogWidget: CreateWidget failed"));
        return;
    }

    QuestLogWidget->AddToViewport(100);
    QuestLogWidget->SetVisibility(ESlateVisibility::Hidden);

    UE_LOG(LogTemp, Log, TEXT("[ExplorationPlayerController] QuestLogWidget created"));
}

void AExplorationPlayerController::BeginPlay()
{
    Super::BeginPlay();

    ApplyExplorationInputMode();
    CreateDialogueWidget();
    CreateQuestLogWidget();
    BindDialogueSubsystem();
}

void AExplorationPlayerController::OnPossess(APawn* InPawn)
{
    Super::OnPossess(InPawn);
    UE_LOG(LogTemp, Warning, TEXT("[ExplorationPC]: OnPossess -> %s"), *GetNameSafe(InPawn));

    ApplyDefaultInputMappings();

    if (ACharacterBase* PossessedCharacter = Cast<ACharacterBase>(InPawn))
    {
        PossessedCharacter->ApplyCharacterInputMapping();
        PossessedCharacter->EnableExplorationMode();
    }

    if (UGameInstance* GI = GetGameInstance())
    {
        if (UGameContextManager* ContextManager = GI->GetSubsystem<UGameContextManager>())
        {
            SetControlRotation(ContextManager->GetSavedExplorationControlRotation());
        }
    }

    if (DialogueSubsystem && DialogueSubsystem->IsDialogueActive())
    {
        ApplyDialogueInputMode();
    }
    else
    {
        ApplyExplorationInputMode();
    }
}

void AExplorationPlayerController::OnUnPossess()
{
    UE_LOG(LogTemp, Warning, TEXT("[ExplorationPC]: OnUnPossess -> %s"), *GetNameSafe(GetPawn()));
    Super::OnUnPossess();
}

void AExplorationPlayerController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (DialogueSubsystem)
    {
        DialogueSubsystem->OnDialogueStarted.RemoveAll(this);
        DialogueSubsystem->OnDialogueEnded.RemoveAll(this);
    }

    Super::EndPlay(EndPlayReason);
}

void AExplorationPlayerController::BindDialogueSubsystem()
{
    UGameInstance* GI = GetGameInstance();
    if (!GI) { return; }

    DialogueSubsystem = GI->GetSubsystem<UDialogueSubsystem>();
    if (!DialogueSubsystem)
    {
        UE_LOG(LogTemp, Warning, TEXT("[ExplorationPlayerController] DialogueSubsystem not found."));
        return;
    }

    DialogueSubsystem->OnDialogueStarted.RemoveAll(this);
    DialogueSubsystem->OnDialogueEnded.RemoveAll(this);

    DialogueSubsystem->OnDialogueStarted.AddUObject(this, &AExplorationPlayerController::HandleDialogueStarted);
    DialogueSubsystem->OnDialogueEnded.AddUObject(this, &AExplorationPlayerController::HandleDialogueEnded);
}

void AExplorationPlayerController::BindQuestSubsystem()
{
    UGameInstance* GI = GetGameInstance();
    if (!GI) { return; }

    QuestSubsystem = GI->GetSubsystem<UQuestSubsystem>();
    if (!QuestSubsystem)
    {
        UE_LOG(LogTemp, Warning, TEXT("[ExplorationPlayerController] DialogueSubsystem not found."));
        return;
    }
}

void AExplorationPlayerController::HandleDialogueStarted()
{
    EnterDialogueInputMode();
}

void AExplorationPlayerController::HandleDialogueEnded()
{
    ExitDialogueInputMode();
}