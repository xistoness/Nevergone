// Copyright Xyzto Works

#include "Widgets/QuestLogWidget.h"
#include "World/QuestSubsystem.h"

void UQuestLogWidget::NativeConstruct()
{
    Super::NativeConstruct();

    UGameInstance* GI = GetGameInstance();
    if (!GI) { return; }

    QuestSubsystem = GI->GetSubsystem<UQuestSubsystem>();
    if (!QuestSubsystem)
    {
        UE_LOG(LogTemp, Error, TEXT("[QuestLogWidget] Failed to find QuestSubsystem."));
        return;
    }

    QuestSubsystem->OnQuestStateChanged.AddUObject(this, &UQuestLogWidget::HandleQuestStateChanged);
    QuestSubsystem->OnQuestStepAdvanced.AddUObject(this, &UQuestLogWidget::HandleQuestStepAdvanced);

    RefreshQuestLog();

    UE_LOG(LogTemp, Log, TEXT("[QuestLogWidget] Constructed."));
}

void UQuestLogWidget::NativeDestruct()
{
    if (QuestSubsystem)
    {
        QuestSubsystem->OnQuestStateChanged.RemoveAll(this);
        QuestSubsystem->OnQuestStepAdvanced.RemoveAll(this);
    }

    Super::NativeDestruct();
}

void UQuestLogWidget::RefreshQuestLog()
{
    if (!QuestSubsystem) { return; }

    BP_ClearQuestLog();

    // Display order: Active first, then Completed, then Failed.
    const TArray<EQuestState> OrderedStates = {
        EQuestState::Active,
        EQuestState::Completed,
        EQuestState::Failed
    };

    for (EQuestState State : OrderedStates)
    {
        TArray<FName> Quests = QuestSubsystem->GetQuestsInState(State);

        for (const FName& QuestName : Quests)
        {
            UQuestData* Asset = LoadQuestAsset(QuestName);

            // Begin quest block — use asset data if available, fall back to FName.
            const FText Title       = Asset ? Asset->Title       : FText::FromName(QuestName);
            const FText Description = Asset ? Asset->Description : FText::GetEmpty();

            BP_BeginQuestEntry(Title, Description, State);

            if (Asset)
            {
                FQuestRuntimeState RuntimeState;
                const bool bHasRuntime = QuestSubsystem->GetRuntimeState(QuestName, RuntimeState);

                // Emit one BP_AddQuestStep for each step that is visible to the player:
                // a step is visible if it has been unlocked or completed at least once.
                for (const FQuestStep& Step : Asset->Steps)
                {
                    const bool bCompleted = bHasRuntime &&
                        RuntimeState.CompletedStepIndices.Contains(Step.StepIndex);

                    const bool bUnlocked = bHasRuntime &&
                        RuntimeState.UnlockedStepIndices.Contains(Step.StepIndex);

                    // Only show steps the player has encountered (unlocked or done).
                    // Locked steps that have never been revealed stay hidden.
                    if (bCompleted || bUnlocked)
                    {
                        BP_AddQuestStep(Step.DiaryEntry, bCompleted);
                    }
                }
            }

            BP_EndQuestEntry();
        }
    }

    UE_LOG(LogTemp, Log, TEXT("[QuestLogWidget] RefreshQuestLog complete."));
}

// ---------------------------------------------------------------------------
// Delegate handlers
// ---------------------------------------------------------------------------

void UQuestLogWidget::HandleQuestStateChanged(FName QuestName, EQuestState NewState)
{
    UE_LOG(LogTemp, Log,
        TEXT("[QuestLogWidget] Quest '%s' state changed to %d — refreshing."),
        *QuestName.ToString(), (int32)NewState);

    RefreshQuestLog();
}

void UQuestLogWidget::HandleQuestStepAdvanced(FName QuestName, int32 StepIndex)
{
    UE_LOG(LogTemp, Log,
        TEXT("[QuestLogWidget] Quest '%s' step %d advanced — refreshing."),
        *QuestName.ToString(), StepIndex);

    RefreshQuestLog();
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

UQuestData* UQuestLogWidget::LoadQuestAsset(FName QuestName) const
{
    const FString AssetPath = FString::Printf(TEXT("/Game/Data/Quests/%s.%s"),
        *QuestName.ToString(), *QuestName.ToString());

    UQuestData* Asset = LoadObject<UQuestData>(nullptr, *AssetPath);
    if (!Asset)
    {
        UE_LOG(LogTemp, Warning,
            TEXT("[QuestLogWidget] Could not load QuestData asset at '%s'."), *AssetPath);
    }
    return Asset;
}
