// Copyright Xyzto Works

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Data/QuestData.h"
#include "QuestLogWidget.generated.h"

class UQuestSubsystem;

/**
 * UQuestLogWidget
 *
 * Quest diary UI. Displays Active, Completed, and Failed quests.
 * Each quest entry shows its diary steps: unlocked steps are shown as pending,
 * completed steps are shown crossed out, locked steps are hidden.
 *
 * The C++ layer handles all subsystem queries and data marshalling.
 * Visual layout (panels, text blocks, strikethrough effects) is done in BP.
 *
 * Refresh flow:
 *  - Full rebuild on open (NativeConstruct → RefreshQuestLog).
 *  - Incremental update on state/step change via delegate callbacks,
 *    which call RefreshQuestLog to keep the implementation simple.
 *    If this becomes a perf concern, targeted refresh can be added later.
 *
 * BP implementation contract:
 *  - BP_BeginQuestEntry / BP_EndQuestEntry bracket each quest block.
 *  - BP_AddQuestStep is called once per visible step inside that block.
 *  - BP_ClearQuestLog is called before every full rebuild.
 */
UCLASS()
class NEVERGONE_API UQuestLogWidget : public UUserWidget
{
    GENERATED_BODY()

public:

    virtual void NativeConstruct() override;
    virtual void NativeDestruct() override;

    // Forces a full rebuild of the diary UI. Called on open and after any change.
    UFUNCTION(BlueprintCallable, Category = "Quest Log")
    void RefreshQuestLog();

protected:

    // --- BP implementation events ---

    // Called once before populating — clear all existing quest entries.
    UFUNCTION(BlueprintImplementableEvent, Category = "Quest Log")
    void BP_ClearQuestLog();

    // Called at the start of each quest block. State is Active/Completed/Failed.
    UFUNCTION(BlueprintImplementableEvent, Category = "Quest Log")
    void BP_BeginQuestEntry(const FText& Title, const FText& Description, EQuestState State);

    // Called once per visible step inside the current quest block.
    // bCompleted = true  → step should be shown crossed out.
    // bCompleted = false → step is unlocked/pending (not yet done).
    UFUNCTION(BlueprintImplementableEvent, Category = "Quest Log")
    void BP_AddQuestStep(const FText& DiaryEntry, bool bCompleted);

    // Called after all steps for the current quest have been added.
    UFUNCTION(BlueprintImplementableEvent, Category = "Quest Log")
    void BP_EndQuestEntry();

private:

    void HandleQuestStateChanged(FName QuestName, EQuestState NewState);
    void HandleQuestStepAdvanced(FName QuestName, int32 StepIndex);

    // Loads the UQuestData asset for QuestName from the conventional path.
    UQuestData* LoadQuestAsset(FName QuestName) const;

    UPROPERTY()
    UQuestSubsystem* QuestSubsystem = nullptr;
};
